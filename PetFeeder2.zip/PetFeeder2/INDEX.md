# Pet Feeder System - Complete Documentation Index

Welcome to the Pet Feeder System! This index will guide you to the right documentation.

---

## 🚀 Quick Start

**New to the project?** Start here:
1. Read [`PROJECT_README.md`](PROJECT_README.md) - Overview and installation
2. Follow [`DEPLOYMENT_CHECKLIST.md`](DEPLOYMENT_CHECKLIST.md) - Step-by-step setup
3. Use [`QUICK_REFERENCE.md`](QUICK_REFERENCE.md) - Common commands

---

## 📚 Documentation Directory

### Getting Started
| Document | Purpose | When to Read |
|----------|---------|--------------|
| [`PROJECT_README.md`](PROJECT_README.md) | Complete project overview, installation guide, features | First time setup |
| [`DEPLOYMENT_CHECKLIST.md`](DEPLOYMENT_CHECKLIST.md) | Detailed deployment steps, testing, troubleshooting | Before deployment |
| [`QUICK_REFERENCE.md`](QUICK_REFERENCE.md) | Quick commands, cheat sheet, common issues | Daily reference |

### Arduino Integration
| Document | Purpose | When to Read |
|----------|---------|--------------|
| [`POWER_AND_WIRING_GUIDE.md`](POWER_AND_WIRING_GUIDE.md) | ⚡ **CRITICAL: Power supply setup, motor wiring** | **READ THIS FIRST!** |
| [`ARDUINO_INTEGRATION_GUIDE.md`](ARDUINO_INTEGRATION_GUIDE.md) | Complete Arduino ↔ RPi setup, protocol, debugging | Setting up hardware |
| [`INTEGRATION_SUMMARY.md`](INTEGRATION_SUMMARY.md) | What was built, how it works, customization | Understanding the system |
| [`README.md`](README.md) | Arduino wiring diagram, hardware connections | Connecting components |

### Architecture & Structure
| Document | Purpose | When to Read |
|----------|---------|--------------|
| [`FILE_STRUCTURE.txt`](FILE_STRUCTURE.txt) | Simple file tree, quick overview | Understanding project layout |
| [`FILE_STRUCTURE_DETAILED.md`](FILE_STRUCTURE_DETAILED.md) | Every file explained in detail, data flow | Deep dive into codebase |
| [`REMAINING_FILES.md`](REMAINING_FILES.md) | Development progress, what's built | Tracking implementation |

### Testing & Maintenance
| Document | Purpose | When to Read |
|----------|---------|--------------|
| [`test_arduino_communication.js`](test_arduino_communication.js) | Standalone Arduino test script | Testing serial communication |
| System logs | Real-time monitoring | During operation |

---

## 🎯 Choose Your Path

### Path 1: I'm Setting Up for the First Time
```
1. POWER_AND_WIRING_GUIDE.md    (⚡ CRITICAL - Power setup!)
2. PROJECT_README.md            (Overview)
3. DEPLOYMENT_CHECKLIST.md      (Setup steps)
4. ARDUINO_INTEGRATION_GUIDE.md (Hardware setup)
5. test_arduino_communication.js (Test connection)
6. QUICK_REFERENCE.md           (Bookmark this!)
```

### Path 2: I Need to Understand the Code
```
1. FILE_STRUCTURE_DETAILED.md  (All files explained)
2. INTEGRATION_SUMMARY.md      (How it works)
3. ARDUINO_INTEGRATION_GUIDE.md (Protocol details)
4. Source code files             (Read the code)
```

### Path 3: I Have an Issue
```
1. QUICK_REFERENCE.md          (Common solutions)
2. DEPLOYMENT_CHECKLIST.md     (Troubleshooting section)
3. ARDUINO_INTEGRATION_GUIDE.md (Debugging guide)
4. test_arduino_communication.js (Test connection)
```

### Path 4: I Want to Customize
```
1. INTEGRATION_SUMMARY.md      (Customization examples)
2. FILE_STRUCTURE_DETAILED.md  (Find relevant files)
3. ARDUINO_INTEGRATION_GUIDE.md (Protocol reference)
4. Source code                  (Modify as needed)
```

---

## 📂 Project Structure Overview

```
PetFeeder2/
│
├── 📖 Documentation (You are here!)
│   ├── INDEX.md                          ← You are here
│   ├── PROJECT_README.md                 ← Start here
│   ├── DEPLOYMENT_CHECKLIST.md           ← Deployment guide
│   ├── ARDUINO_INTEGRATION_GUIDE.md      ← Hardware setup
│   ├── INTEGRATION_SUMMARY.md            ← How it works
│   ├── QUICK_REFERENCE.md                ← Cheat sheet
│   ├── FILE_STRUCTURE.txt                ← Simple tree
│   ├── FILE_STRUCTURE_DETAILED.md        ← Detailed tree
│   ├── REMAINING_FILES.md                ← Progress tracker
│   └── README.md                         ← Arduino wiring
│
├── 🖥️  Backend (Node.js + Express)
│   ├── server.js                         ← Main server
│   ├── database/
│   │   ├── init.js                       ← Database setup
│   │   └── petfeeder.db                  ← SQLite database
│   ├── routes/
│   │   ├── auth.js                       ← Login/logout
│   │   ├── admin.js                      ← Admin endpoints
│   │   ├── user.js                       ← User endpoints
│   │   └── api.js                        ← Arduino API
│   ├── middleware/
│   │   ├── authMiddleware.js             ← Auth checks
│   │   └── adminMiddleware.js            ← Admin checks
│   └── serial/
│       └── arduinoSerial.js              ← Arduino bridge
│
├── 🌐 Frontend (HTML + CSS + JS)
│   ├── index.html                        ← Login page
│   ├── admin/
│   │   ├── admin.html                    ← Admin dashboard
│   │   ├── admin.css                     ← Admin styles
│   │   └── admin.js                      ← Admin logic
│   ├── user/
│   │   ├── user.html                     ← User dashboard
│   │   ├── user.css                      ← User styles
│   │   └── user.js                       ← User logic
│   └── public/                           ← Static assets
│
├── 🔧 Arduino
│   └── pet_feeder.ino                    ← Arduino code
│
└── 🧪 Testing
    └── test_arduino_communication.js     ← Test script
```

---

## 🔑 Key Concepts

### Authentication System
- **Sessions:** Express session-based authentication
- **Passwords:** Bcrypt hashing
- **Roles:** Admin and User roles
- **Pages:** Login → Admin Dashboard or User Dashboard

### Arduino Communication
- **Protocol:** USB Serial (UART) at 115200 baud
- **Commands:** DISPENSE_FOOD, DISPENSE_WATER, DISPENSE_BOTH, GET_STATUS
- **Responses:** FOOD_DONE, WATER_DONE, BOTH_DONE, STATUS_ONLINE
- **Bridge:** `serial/arduinoSerial.js` handles all communication

### Real-time Updates
- **Technology:** Socket.IO WebSockets
- **Events:** arduino-status, dispense-complete, arduino-response, arduino-error
- **Purpose:** Instant updates across all connected browsers

### Database
- **Type:** SQLite (serverless)
- **Tables:** users, schedules, feeding_logs, commands, notifications, device_status, system_logs
- **Location:** `database/petfeeder.db`

---

## 🎓 Learning Resources

### Understanding the System

**Question:** How does a feed button click reach the Arduino?
**Answer:** See [`INTEGRATION_SUMMARY.md`](INTEGRATION_SUMMARY.md#-complete-communication-flow)

**Question:** What commands can I send to Arduino?
**Answer:** See [`ARDUINO_INTEGRATION_GUIDE.md`](ARDUINO_INTEGRATION_GUIDE.md#-communication-protocol)

**Question:** How do I add a new API endpoint?
**Answer:** See [`INTEGRATION_SUMMARY.md`](INTEGRATION_SUMMARY.md#-customization-examples)

**Question:** Where is user data stored?
**Answer:** See [`FILE_STRUCTURE_DETAILED.md`](FILE_STRUCTURE_DETAILED.md#database) - Database section

**Question:** How do real-time updates work?
**Answer:** See [`ARDUINO_INTEGRATION_GUIDE.md`](ARDUINO_INTEGRATION_GUIDE.md#-monitoring--logs)

---

## 🛠️ Common Tasks

### Task: Test Arduino Connection
```bash
node test_arduino_communication.js
```
See: [`ARDUINO_INTEGRATION_GUIDE.md`](ARDUINO_INTEGRATION_GUIDE.md#-setup-steps)

### Task: Add a New User
1. Login as admin (admin/admin123)
2. Go to User Management
3. Click "Add User"
Or see: [`DEPLOYMENT_CHECKLIST.md`](DEPLOYMENT_CHECKLIST.md#test-2-schedule-creation)

### Task: Create a Schedule
1. Login as user
2. Go to Schedules
3. Click "Add Schedule"
Or see: [`DEPLOYMENT_CHECKLIST.md`](DEPLOYMENT_CHECKLIST.md#test-2-schedule-creation)

### Task: View Logs
```bash
# Server logs
sudo journalctl -u petfeeder -f

# Database logs
sqlite3 database/petfeeder.db "SELECT * FROM system_logs ORDER BY created_at DESC LIMIT 20;"
```
See: [`DEPLOYMENT_CHECKLIST.md`](DEPLOYMENT_CHECKLIST.md#-monitoring-commands)

### Task: Backup Database
```bash
cp database/petfeeder.db database/petfeeder.db.backup
```
See: [`DEPLOYMENT_CHECKLIST.md`](DEPLOYMENT_CHECKLIST.md#issue-database-errors)

### Task: Reset System
```bash
rm database/petfeeder.db
node database/init.js
npm start
```
See: [`QUICK_REFERENCE.md`](QUICK_REFERENCE.md#-common-issues)

---

## 📊 System Capabilities

### What the System Can Do
✅ Manual feeding (Food, Water, or Both)
✅ Scheduled feeding (up to 6 schedules per user)
✅ Real-time device monitoring
✅ Feeding history tracking
✅ CSV export of feeding data
✅ Pet profile management
✅ User account management (admin)
✅ Dark theme support
✅ Mobile responsive design
✅ 10-second cooldown between manual feeds
✅ Auto-reconnect to Arduino
✅ Session persistence (24 hours)
✅ EEPROM storage on Arduino
✅ Keypad control directly on Arduino

### What's Required
- Raspberry Pi 4 (or any Linux/Windows machine with Node.js)
- Arduino Uno
- USB cable (data, not charge-only)
- Servo motor for food
- Water pump with relay/driver
- RTC module (DS3231)
- I2C LCD (16x2)
- 4x4 Matrix keypad
- Network connection (for web access)

---

## 🚨 Emergency Quick Fixes

### Arduino Disconnected
```bash
# Find port
ls /dev/tty*

# Fix permissions
sudo chmod 666 /dev/ttyUSB0

# Restart server
# Ctrl+C then npm start
```

### Server Crashed
```bash
# Restart
npm start

# Or if using systemd
sudo systemctl restart petfeeder
```

### Can't Login
```bash
# Reset admin password to default
node database/init.js
# Login: admin / admin123
```

### Feed Button Not Working
1. Check Device Monitoring - is Arduino online?
2. Check browser console (F12) for errors
3. Test: `node test_arduino_communication.js`
4. If offline, unplug/replug Arduino USB

---

## 📞 Getting Help

### Before Asking for Help

1. **Check documentation:** Use this index to find relevant docs
2. **Check logs:** 
   - Server terminal output
   - Browser console (F12)
   - Arduino Serial Monitor
3. **Run test script:** `node test_arduino_communication.js`
4. **Try QUICK_REFERENCE.md:** Common solutions

### When Reporting Issues

Include:
- What you were trying to do
- Error message (exact text)
- Server logs (last 20 lines)
- Browser console errors
- Arduino Serial Monitor output
- Node.js version: `node --version`
- OS: `uname -a` or Windows version

---

## 🎉 Success Checklist

System is working correctly when:
- [ ] Server starts without errors
- [ ] Arduino shows "Online" in dashboard
- [ ] Login works for admin and users
- [ ] Feed buttons trigger Arduino actions
- [ ] Real-time updates appear
- [ ] Schedules execute automatically
- [ ] History logs correctly
- [ ] Can access from mobile devices
- [ ] Database persists after restart
- [ ] No errors for 24 hours of operation

---

## 🔄 Update Log

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | June 7, 2026 | Initial complete system |
| - | - | - |

---

## 📝 License & Credits

**License:** MIT License
**Created:** June 7, 2026
**Platform:** Raspberry Pi 4 + Arduino Uno
**Technologies:** Node.js, Express, Socket.IO, SQLite, Arduino C++

---

## 🎯 Start Here

**First time user?** → [`PROJECT_README.md`](PROJECT_README.md)

**Ready to deploy?** → [`DEPLOYMENT_CHECKLIST.md`](DEPLOYMENT_CHECKLIST.md)

**Need quick help?** → [`QUICK_REFERENCE.md`](QUICK_REFERENCE.md)

**Arduino setup?** → [`ARDUINO_INTEGRATION_GUIDE.md`](ARDUINO_INTEGRATION_GUIDE.md)

---

**Happy Pet Feeding! 🐾**
