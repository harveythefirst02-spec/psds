# Pet Feeder System - Detailed File Structure

## 📁 Complete Project Structure with Descriptions

```
PetFeeder2/
│
├── 📦 node_modules/                    
│   └── Contains all installed Node.js packages and dependencies
│       (express, socket.io, sqlite3, bcrypt, serialport, etc.)
│
├── 💾 database/
│   ├── init.js                      
│   │   └── Database initialization script that:
│   │       • Creates all SQLite tables (users, schedules, feeding_logs, etc.)
│   │       • Sets up indexes for performance
│   │       • Creates default admin account (admin/admin123)
│   │       • Inserts default system settings
│   │
│   └── petfeeder.db                 
│       └── SQLite database file (auto-created after running init.js)
│           • Stores all user data, schedules, logs, and settings
│           • Lightweight, serverless database
│
├── 🔒 middleware/
│   ├── authMiddleware.js            
│   │   └── Authentication middleware that:
│   │       • Verifies user session exists
│   │       • Checks if account is active
│   │       • Protects routes from unauthorized access
│   │       • Redirects unauthenticated users to login
│   │
│   └── adminMiddleware.js           
│       └── Admin authorization middleware that:
│           • Verifies user has admin role
│           • Prevents non-admin users from accessing admin routes
│           • Returns 403 Forbidden for unauthorized access
│
├── 🛣️  routes/
│   ├── auth.js                      
│   │   └── Authentication endpoints:
│   │       • POST /auth/login - User login with bcrypt password verification
│   │       • POST /auth/logout - Destroy user session
│   │       • GET /auth/check-session - Verify if user is logged in
│   │
│   ├── admin.js                     
│   │   └── Admin dashboard endpoints:
│   │       • GET /admin/stats - Dashboard statistics
│   │       • GET /admin/users - List all users
│   │       • POST /admin/users - Create new user
│   │       • PUT /admin/users/:id - Update user details
│   │       • PATCH /admin/users/:id/status - Enable/disable user
│   │       • PATCH /admin/users/:id/password - Reset user password
│   │       • DELETE /admin/users/:id - Delete user and all data
│   │       • GET /admin/logs - System logs with filtering
│   │       • GET /admin/feeding-logs - Feeding logs with filtering
│   │       • GET /admin/device-status - Arduino/RPi status
│   │       • GET /admin/settings - System settings
│   │       • PUT /admin/settings - Update system settings
│   │
│   ├── user.js                      
│   │   └── User dashboard endpoints:
│   │       • GET /user/dashboard - Home page data (pet info, last feeding, next schedule)
│   │       • GET /user/schedules - User's feeding schedules
│   │       • POST /user/schedules - Create new schedule
│   │       • PUT /user/schedules/:id - Update schedule
│   │       • PATCH /user/schedules/:id/status - Enable/disable schedule
│   │       • DELETE /user/schedules/:id - Delete schedule
│   │       • GET /user/feeding-history - Feeding history with filters
│   │       • PUT /user/profile - Update pet profile
│   │       • PUT /user/change-password - Change user password
│   │       • GET /user/settings - User preferences
│   │       • PUT /user/settings - Update preferences (theme, notifications)
│   │       • GET /user/notifications - User notifications
│   │       • PATCH /user/notifications/:id/read - Mark notification as read
│   │
│   └── api.js                       
│       └── Arduino communication endpoints:
│           • POST /api/dispense/food - Send DISPENSE_FOOD command
│           • POST /api/dispense/water - Send DISPENSE_WATER command
│           • POST /api/dispense/both - Send DISPENSE_BOTH command
│           • GET /api/arduino/status - Check Arduino connection
│           • POST /api/arduino/test - Test Arduino communication
│
├── 🔌 serial/
│   └── arduinoSerial.js             
│       └── Arduino USB serial communication module:
│           • Connects to Arduino via USB (auto-detects port)
│           • Sends commands: DISPENSE_FOOD, DISPENSE_WATER, DISPENSE_BOTH, GET_STATUS
│           • Receives responses: FOOD_DONE, WATER_DONE, BOTH_DONE, STATUS_ONLINE, ERROR
│           • Handles serial port errors and reconnection
│           • Logs all commands and responses to database
│           • Broadcasts Arduino events via Socket.IO
│           • Updates device status in real-time
│           • Maintains command queue and timeout handling
│
├── 👨‍💼 admin/
│   ├── admin.html                   
│   │   └── Admin dashboard single-page application:
│   │       • Navigation: Overview, Users, Logs, Device, Settings
│   │       • Overview: Statistics cards with real-time updates
│   │       • User Management: CRUD operations, enable/disable, password reset
│   │       • System Logs: Filterable logs (today/week/month)
│   │       • Feeding Logs: Complete feeding history
│   │       • Device Monitoring: Arduino and RPi status
│   │       • System Settings: Feed duration, pump duration, notifications
│   │       • Modals: Add/Edit user, Reset password
│   │
│   ├── admin.css                    
│   │   └── Admin dashboard styling:
│   │       • Responsive grid layout
│   │       • Sidebar navigation with active states
│   │       • Statistics cards with hover effects
│   │       • Data tables with sorting
│   │       • Modal dialogs
│   │       • Form styling
│   │       • Button variants (primary, success, warning, danger)
│   │       • Toast notifications
│   │       • Mobile responsive (hamburger menu)
│   │
│   └── admin.js                     
│       └── Admin dashboard functionality:
│           • Socket.IO connection for real-time updates
│           • Navigation system (section switching)
│           • Dashboard statistics loader
│           • User CRUD operations with API calls
│           • Modal management (open/close/populate)
│           • Log filtering and display
│           • Device status monitoring
│           • Settings management
│           • Form validation
│           • Toast notifications
│           • Auto-refresh every 30 seconds
│
├── 👤 user/
│   ├── user.html                    
│   │   └── User dashboard single-page application:
│   │       • Navigation: Home, Feed Control, Schedules, History, Profile, Settings
│   │       • Home: Pet info, last feeding, next schedule, device status
│   │       • Feed Control: 3 big buttons (Food, Water, Both) with cooldown
│   │       • Schedules: Grid of schedule cards with edit/delete/toggle
│   │       • History: Filterable table with export CSV
│   │       • Profile: Pet details form (name, type, age, weight)
│   │       • Settings: Password change, theme switcher, notifications
│   │       • Modals: Add/Edit schedule, Confirmation dialog
│   │
│   ├── user.css                     
│   │   └── User dashboard styling:
│   │       • Responsive sidebar navigation
│   │       • Dashboard cards with icons
│   │       • Large feed control buttons with hover effects
│   │       • Schedule card grid layout
│   │       • Data table styling
│   │       • Form layouts (profile, settings)
│   │       • Modal dialogs
│   │       • Toast notifications
│   │       • Dark theme support
│   │       • Mobile responsive (collapsible sidebar)
│   │       • Status indicators (online/offline dots)
│   │
│   └── user.js                      
│       └── User dashboard functionality:
│           • Socket.IO connection for real-time updates
│           • Navigation system with section switching
│           • Dashboard data loader
│           • Manual dispense with confirmation and cooldown (10s)
│           • Schedule CRUD operations
│           • Schedule toggle (enable/disable)
│           • Feeding history with filtering
│           • CSV export functionality
│           • Pet profile management
│           • Password change
│           • Theme switcher (light/dark)
│           • Preferences management
│           • Real-time Arduino status updates
│           • Toast notifications
│           • Auto-refresh every 30 seconds
│
├── 🌐 public/
│   ├── css/                         
│   │   └── Additional public CSS files (optional)
│   │
│   ├── js/                          
│   │   └── Additional public JavaScript files (optional)
│   │
│   └── assets/                      
│       └── Images, icons, logos (optional)
│
├── 🔐 index.html                    
│   └── Login page:
│       • Clean, modern design with gradient background
│       • Email/username and password fields
│       • Form validation
│       • Loading state
│       • Error/success alerts
│       • Responsive design
│       • Auto-redirect if already logged in
│       • Session checking on load
│
├── 🖥️  server.js                     
│   └── Main Express server:
│       • Express app initialization
│       • HTTP server with Socket.IO
│       • Session configuration (24-hour expiry)
│       • Body parser and cookie parser middleware
│       • Static file serving (admin, user, public)
│       • SQLite database connection
│       • Route mounting (auth, admin, user, api)
│       • Root route with session redirect
│       • Socket.IO event handling
│       • Arduino serial initialization
│       • Graceful shutdown handling
│       • Listens on port 3000 (configurable)
│
├── 📋 package.json                  
│   └── Node.js project configuration:
│       • Project metadata (name, version, description)
│       • Dependencies: express, socket.io, sqlite3, bcrypt, serialport, etc.
│       • Scripts: start, dev, init-db
│       • Development dependencies: nodemon
│
├── 🔒 package-lock.json             
│   └── Dependency lock file (auto-generated by npm install)
│       • Ensures consistent dependency versions
│       • Contains exact versions and integrity hashes
│
├── 🔧 pet_feeder.ino                
│   └── Complete Arduino code:
│       • RTC-based scheduling system
│       • 12-hour time format with AM/PM
│       • Up to 6 feeding schedules
│       • Keypad controls (A=Add, B=View, C=Delete, D=Clear)
│       • I2C LCD display (16x2)
│       • Servo motor control for food dispensing
│       • Water pump control
│       • EEPROM storage for schedules
│       • Time conversion functions (12hr ↔ 24hr)
│       • Input validation
│       • Three dispense modes: Food Only, Water Only, Both
│       • Trigger protection (prevents multiple executions)
│       • Serial debugging output
│       • Well-commented and structured code
│
├── 📖 README.md                     
│   └── Arduino wiring guide:
│       • Servo motor wiring (Pin 10)
│       • Water pump wiring (Pin 11)
│       • Keypad wiring (Pins 2-9)
│       • I2C LCD wiring (A4/A5)
│       • RTC module wiring (A4/A5)
│       • Pin configuration diagram
│       • Hardware requirements
│       • Library installation instructions
│
├── 📚 PROJECT_README.md             
│   └── Complete setup guide:
│       • System architecture overview
│       • Technology stack details
│       • Raspberry Pi setup instructions
│       • Node.js installation
│       • Project installation steps
│       • Arduino USB connection setup
│       • Arduino code upload guide
│       • Server startup commands
│       • Network access configuration
│       • Default login credentials
│       • Database table descriptions
│       • Arduino command protocol
│       • Port configuration
│       • Auto-start on boot setup
│       • Troubleshooting guide
│       • Security features
│       • Performance optimizations
│
├── ✅ REMAINING_FILES.md            
│   └── Development progress tracker:
│       • List of completed files
│       • Files that need to be created
│       • Quick setup instructions
│       • Feature checklist
│       • Testing guide
│       • Next steps and recommendations
│
└── 📄 FILE_STRUCTURE.txt            
    └── Simple file tree structure (this file's sibling)
        • Quick reference tree view
        • File count summary

═══════════════════════════════════════════════════════════

## 📊 Summary Statistics

**Total Directories:** 7
- database/ (1 file)
- middleware/ (2 files)
- routes/ (4 files)
- serial/ (1 file)
- admin/ (3 files)
- user/ (3 files)
- public/ (3 subdirectories)

**Total Core Files:** ~25 files
- Backend: 12 files (server, routes, middleware, serial, database)
- Frontend: 7 files (HTML, CSS, JS for admin & user + login)
- Arduino: 1 file (.ino)
- Documentation: 4 files (README, guides, structure)
- Configuration: 2 files (package.json, package-lock.json)

**Lines of Code:** ~5,000+ lines
- JavaScript (Backend): ~2,500 lines
- JavaScript (Frontend): ~1,500 lines
- CSS: ~800 lines
- HTML: ~600 lines
- Arduino C++: ~600 lines

═══════════════════════════════════════════════════════════

## 🔄 Data Flow

```
User Browser
    ↓ HTTP Request
Express Server (server.js)
    ↓ Route Handling
Routes (auth.js, admin.js, user.js, api.js)
    ↓ Database Query / Serial Command
SQLite Database / Arduino Serial (arduinoSerial.js)
    ↓ Response / Arduino Reply
Express Server
    ↓ Socket.IO Broadcast (Real-time)
All Connected Clients
```

## 🔐 Authentication Flow

```
Login (index.html)
    ↓ POST /auth/login
Authentication (authMiddleware.js)
    ↓ Password Verification (bcrypt)
Database (users table)
    ↓ Create Session
Express Session
    ↓ Redirect Based on Role
Admin Dashboard (admin.html) OR User Dashboard (user.html)
```

## 📡 Arduino Communication Flow

```
User Action (Click "Food" button)
    ↓ POST /api/dispense/food
API Route (api.js)
    ↓ Send Command
Arduino Serial (arduinoSerial.js)
    ↓ USB Serial (DISPENSE_FOOD)
Arduino Nano
    ↓ Execute & Respond (FOOD_DONE)
Arduino Serial
    ↓ Parse Response
Database Logging (feeding_logs)
    ↓ Socket.IO Broadcast
All Connected Clients (Real-time Update)
```

═══════════════════════════════════════════════════════════

## 🎯 Key Features by File

### Backend (Node.js + Express)
- **server.js**: Main application, routing, Socket.IO
- **routes/*.js**: RESTful API endpoints
- **middleware/*.js**: Authentication & authorization
- **serial/arduinoSerial.js**: Hardware communication
- **database/init.js**: Database setup & seeding

### Frontend (HTML/CSS/JS)
- **index.html**: Login interface
- **admin/**: Complete admin dashboard
- **user/**: Complete user dashboard
- **public/**: Shared assets

### Hardware (Arduino)
- **pet_feeder.ino**: Embedded system code
- RTC scheduling, servo control, pump control
- Keypad interface, LCD display

### Documentation
- **PROJECT_README.md**: Setup & deployment guide
- **README.md**: Arduino wiring guide
- **FILE_STRUCTURE.md**: This detailed guide

═══════════════════════════════════════════════════════════

Created: June 7, 2026
Last Updated: June 7, 2026
Version: 1.0.0
