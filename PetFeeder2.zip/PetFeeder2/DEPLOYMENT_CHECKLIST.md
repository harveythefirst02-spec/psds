# Pet Feeder System - Deployment Checklist

## 📋 Pre-Deployment Checklist

### ✅ Backend Setup
- [ ] Node.js installed (v14 or higher)
- [ ] All dependencies installed (`npm install`)
- [ ] Database initialized (`node database/init.js`)
- [ ] Default admin account created (admin/admin123)
- [ ] Server starts without errors (`npm start`)
- [ ] Server accessible on http://localhost:3000

### ✅ Arduino Setup
- [ ] Arduino IDE installed
- [ ] Required libraries installed:
  - [ ] Wire (built-in)
  - [ ] LiquidCrystal_I2C
  - [ ] RTClib (Adafruit)
  - [ ] Keypad
  - [ ] Servo (built-in)
  - [ ] EEPROM (built-in)
- [ ] pet_feeder.ino uploaded successfully
- [ ] Arduino shows initialization messages in Serial Monitor
- [ ] RTC set to correct time
- [ ] LCD displays current time

### ✅ Hardware Connections
- [ ] Arduino connected to Raspberry Pi via USB
- [ ] Serial port detected (`ls /dev/tty*` or check Device Manager)
- [ ] Servo motor wired to Pin 10
- [ ] Water pump wired to Pin 11
- [ ] Keypad wired to Pins 2-9
- [ ] I2C LCD connected (SDA=A4, SCL=A5)
- [ ] RTC module connected (SDA=A4, SCL=A5)
- [ ] Power supply adequate for all components

### ✅ Network Setup
- [ ] Raspberry Pi connected to network
- [ ] Static IP configured (optional but recommended)
- [ ] Port 3000 open in firewall
- [ ] Server accessible from other devices on network

### ✅ Communication Test
- [ ] Run `node test_arduino_communication.js`
- [ ] GET_STATUS returns STATUS_ONLINE
- [ ] DISPENSE_FOOD returns FOOD_DONE
- [ ] DISPENSE_WATER returns WATER_DONE
- [ ] DISPENSE_BOTH returns BOTH_DONE
- [ ] No timeout errors
- [ ] Responses appear in under 2 seconds

### ✅ Web Interface Test
- [ ] Login page loads
- [ ] Admin login works (admin/admin123)
- [ ] Admin dashboard displays statistics
- [ ] Admin can create user accounts
- [ ] User login works
- [ ] User dashboard loads all sections
- [ ] Feed control buttons visible
- [ ] Schedule management works
- [ ] Device status shows "Online"

### ✅ Database Verification
```bash
# Check database file exists
ls -lh database/petfeeder.db

# Should see file ~100KB or larger
```

### ✅ Real-time Features
- [ ] Socket.IO connects (check browser console)
- [ ] Arduino status updates in real-time
- [ ] Feed completion shows toast notification
- [ ] Dashboard statistics auto-refresh
- [ ] Multiple browsers stay in sync

---

## 🚀 Deployment Steps

### Step 1: Prepare Raspberry Pi

```bash
# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Install Node.js (if not installed)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version  # Should be v18.x or higher
npm --version

# Install build tools
sudo apt-get install -y build-essential
```

### Step 2: Transfer Project Files

```bash
# Option A: Using Git
cd ~
git clone <your-repo-url> PetFeeder2
cd PetFeeder2

# Option B: Using SCP from your computer
# scp -r /path/to/PetFeeder2 pi@<raspberry-pi-ip>:~/

# Option C: USB drive
# Copy files to USB → Insert into RPi → Copy to home directory
```

### Step 3: Install Dependencies

```bash
cd ~/PetFeeder2
npm install

# This will take 3-5 minutes
# Expected: ~286 packages installed
```

### Step 4: Initialize Database

```bash
node database/init.js

# Expected output:
# ✓ Users table created/verified
# ✓ Schedules table created/verified
# ... (all tables)
# ✓ Default admin account created
# Database initialization complete!
```

### Step 5: Configure Serial Port

```bash
# Find Arduino port
ls /dev/tty* | grep -E 'USB|ACM'

# Typical outputs:
# /dev/ttyUSB0  (USB to Serial adapter)
# /dev/ttyACM0  (Arduino Uno)

# Give permissions
sudo chmod 666 /dev/ttyUSB0
sudo usermod -a -G dialout $USER

# Reboot for group changes
sudo reboot
```

### Step 6: Test Arduino Communication

```bash
cd ~/PetFeeder2
node test_arduino_communication.js

# Expected:
# ✓ Found potential Arduino on: /dev/ttyUSB0
# ✓ Serial port opened successfully!
# Test 1: Status Check → ← Arduino: STATUS_ONLINE
```

### Step 7: Start Server

```bash
npm start

# Expected:
# ✓ Connected to SQLite database
# ✓ Connected to Arduino on /dev/ttyUSB0
# Server running on port 3000
```

### Step 8: Test Web Access

```bash
# On Raspberry Pi
curl http://localhost:3000

# From another device on same network
# Get RPi IP address
hostname -I  # Example: 192.168.1.100

# Open browser on another device:
# http://192.168.1.100:3000
```

### Step 9: Login and Test

1. Open browser: http://raspberry-pi-ip:3000
2. Login as admin: `admin` / `admin123`
3. Create a test user account
4. Logout and login as user
5. Test feed buttons
6. Create a test schedule
7. Verify Arduino response

---

## 🔄 Auto-Start on Boot

### Create systemd Service

```bash
# Create service file
sudo nano /etc/systemd/system/petfeeder.service
```

**Paste this configuration:**
```ini
[Unit]
Description=Pet Feeder System
After=network.target

[Service]
Type=simple
User=pi
WorkingDirectory=/home/pi/PetFeeder2
ExecStart=/usr/bin/node server.js
Restart=on-failure
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

**Enable and start service:**
```bash
# Reload systemd
sudo systemctl daemon-reload

# Enable auto-start
sudo systemctl enable petfeeder.service

# Start service now
sudo systemctl start petfeeder.service

# Check status
sudo systemctl status petfeeder.service

# View logs
sudo journalctl -u petfeeder.service -f
```

---

## 🧪 Post-Deployment Testing

### Test 1: Manual Feed
1. Login as user
2. Go to Feed Control
3. Click "FOOD ONLY"
4. Confirm action
5. **Expected:** Servo rotates, "FOOD DISPENSED!" appears
6. **Check:** 10-second cooldown activates

### Test 2: Schedule Creation
1. Go to Schedules section
2. Click "Add Schedule"
3. Enter: Hour=8, Minute=30, AM/PM=AM, Type=Food
4. Save
5. **Expected:** Schedule card appears
6. **Check:** Dashboard shows "Next: 8:30 AM F"

### Test 3: Real-time Updates
1. Open browser on device A (user logged in)
2. Open browser on device B (admin logged in)
3. From device A, click "WATER ONLY"
4. **Expected:** Both browsers show update simultaneously
5. **Check:** Admin sees log in "Feeding Logs"

### Test 4: Arduino Disconnect
1. Unplug Arduino USB cable
2. **Expected:** Device status shows "Offline"
3. **Expected:** Feed buttons show error if clicked
4. Reconnect Arduino
5. **Expected:** Status changes to "Online" within 10 seconds

### Test 5: Schedule Execution
1. Create schedule for 2 minutes from now
2. Wait for time to arrive
3. **Expected:** Arduino executes automatically
4. **Expected:** Dashboard updates last feeding time
5. **Check:** History shows "Schedule" as source

### Test 6: Database Persistence
1. Create a user and schedule
2. Stop server (Ctrl+C)
3. Restart server (npm start)
4. Login as user
5. **Expected:** Schedule still exists
6. **Expected:** Pet profile data intact

### Test 7: Mobile Access
1. Connect phone to same WiFi
2. Open browser: http://raspberry-pi-ip:3000
3. Login as user
4. **Expected:** Mobile-responsive layout
5. Test feed buttons from mobile

### Test 8: Export History
1. Go to History section
2. Create some feeding events
3. Click "Export CSV"
4. **Expected:** CSV file downloads
5. Open file in Excel/Sheets
6. **Expected:** All data correctly formatted

---

## 🔒 Security Hardening (Optional)

### Change Default Admin Password
```javascript
// After first login, go to Settings → Change Password
// Or via database:
const bcrypt = require('bcrypt');
const hash = bcrypt.hashSync('new-secure-password', 10);
// Update in database
```

### Enable HTTPS (Optional)
```bash
# Install SSL certificate
sudo apt-get install certbot

# Generate certificate
sudo certbot certonly --standalone -d yourdomain.com

# Update server.js to use HTTPS
```

### Firewall Configuration
```bash
# Install UFW
sudo apt-get install ufw

# Allow SSH
sudo ufw allow 22

# Allow web server
sudo ufw allow 3000

# Enable firewall
sudo ufw enable

# Check status
sudo ufw status
```

---

## 📊 Monitoring Commands

### Check Server Status
```bash
# If using systemd
sudo systemctl status petfeeder

# If running manually
ps aux | grep node

# Check port
sudo netstat -tulpn | grep 3000
```

### View Logs
```bash
# Systemd logs
sudo journalctl -u petfeeder -f

# Manual server logs (if running with npm start)
# Just view terminal output
```

### Database Statistics
```bash
# Enter SQLite
sqlite3 database/petfeeder.db

# Check user count
SELECT COUNT(*) FROM users WHERE role='user';

# Check schedule count
SELECT COUNT(*) FROM schedules WHERE is_active=1;

# Recent feedings
SELECT * FROM feeding_logs ORDER BY timestamp DESC LIMIT 10;

# Exit
.exit
```

### Arduino Connection
```bash
# Check if Arduino is connected
ls /dev/tty* | grep -E 'USB|ACM'

# Test communication
node test_arduino_communication.js
```

---

## 🐛 Troubleshooting Guide

### Issue: Server won't start
```bash
# Check if port 3000 is in use
sudo lsof -i :3000

# Kill process if needed
sudo kill -9 <PID>

# Check Node.js version
node --version  # Should be v14+

# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

### Issue: Arduino not connecting
```bash
# Check USB connection
lsusb

# Check permissions
ls -l /dev/ttyUSB0

# Fix permissions
sudo chmod 666 /dev/ttyUSB0

# Add user to dialout group
sudo usermod -a -G dialout $USER
sudo reboot
```

### Issue: Database errors
```bash
# Backup current database
cp database/petfeeder.db database/petfeeder.db.backup

# Reinitialize
rm database/petfeeder.db
node database/init.js

# Restore if needed
cp database/petfeeder.db.backup database/petfeeder.db
```

### Issue: WebSocket not connecting
```javascript
// Check browser console
// Should see: Socket.IO connected

// If not, check firewall
sudo ufw allow 3000

// Check server logs for errors
```

### Issue: Commands timing out
```bash
# Check Arduino Serial Monitor
# Baud rate should be 115200

# Re-upload Arduino code
# Restart server

# Test directly
node test_arduino_communication.js
```

---

## 📱 Accessing from Internet (Advanced)

### Option 1: Port Forwarding
1. Login to your router (usually 192.168.1.1)
2. Find Port Forwarding settings
3. Forward external port 8080 → internal port 3000
4. Access via: http://your-public-ip:8080

### Option 2: Ngrok (Temporary)
```bash
# Install ngrok
npm install -g ngrok

# Start tunnel
ngrok http 3000

# Use provided URL (e.g., https://abc123.ngrok.io)
```

### Option 3: VPN (Recommended)
Use Tailscale or WireGuard for secure remote access

---

## 🎯 Success Criteria

✅ **System is Ready When:**
- [ ] Server starts automatically on boot
- [ ] Arduino stays connected 24/7
- [ ] Users can access from any device on network
- [ ] Schedules execute reliably
- [ ] Feed buttons work consistently
- [ ] Real-time updates work
- [ ] Database persists across restarts
- [ ] No errors in logs for 24 hours
- [ ] Mobile access works
- [ ] History exports correctly

---

## 📞 Support Checklist

**Before asking for help, provide:**
1. Server logs (last 50 lines)
2. Arduino Serial Monitor output
3. Browser console errors (F12)
4. Output of `node test_arduino_communication.js`
5. Database file size: `ls -lh database/petfeeder.db`
6. Node.js version: `node --version`
7. OS info: `uname -a` or `cat /etc/os-release`

---

## 🎉 Deployment Complete!

**Next Steps:**
1. Monitor system for 24 hours
2. Test all schedules
3. Add more users if needed
4. Set up regular database backups
5. Consider adding notifications
6. Add weight sensors for smart feeding
7. Integrate camera for pet monitoring

**Enjoy your automated pet feeder system!** 🐾

---

**Version:** 1.0.0
**Last Updated:** June 7, 2026
**Status:** Production Ready ✅
