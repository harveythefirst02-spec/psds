/*
 * Arduino Communication Test Script
 * Run this to test serial communication between Raspberry Pi and Arduino
 * Usage: node test_arduino_communication.js
 */

const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');

console.log('=================================');
console.log('Arduino Communication Test');
console.log('=================================\n');

// Find available ports
SerialPort.list().then(ports => {
  console.log('Available Serial Ports:');
  ports.forEach((port, index) => {
    console.log(`${index + 1}. ${port.path}`);
    if (port.manufacturer) console.log(`   Manufacturer: ${port.manufacturer}`);
    if (port.serialNumber) console.log(`   Serial: ${port.serialNumber}`);
  });
  
  // Try to connect to first USB port
  const arduinoPort = ports.find(p => 
    p.path.includes('ttyUSB') || 
    p.path.includes('ttyACM') ||
    p.path.includes('COM')
  );
  
  if (!arduinoPort) {
    console.error('\n❌ No Arduino found. Please connect Arduino via USB.');
    process.exit(1);
  }
  
  console.log(`\n✓ Found potential Arduino on: ${arduinoPort.path}`);
  console.log('Attempting to connect...\n');
  
  // Connect
  const port = new SerialPort({
    path: arduinoPort.path,
    baudRate: 115200
  });
  
  const parser = port.pipe(new ReadlineParser({ delimiter: '\r\n' }));
  
  port.on('open', () => {
    console.log('✓ Serial port opened successfully!\n');
    console.log('=================================');
    console.log('Starting Communication Tests');
    console.log('=================================\n');
    
    // Wait 2 seconds for Arduino to initialize
    setTimeout(() => {
      runTests(port);
    }, 2000);
  });
  
  port.on('error', (err) => {
    console.error('❌ Serial port error:', err.message);
    process.exit(1);
  });
  
  parser.on('data', (data) => {
    console.log('← Arduino:', data);
  });
  
}).catch(err => {
  console.error('Error listing ports:', err);
  process.exit(1);
});

function runTests(port) {
  let testNumber = 0;
  
  const tests = [
    { name: 'Status Check', command: 'GET_STATUS' },
    { name: 'Food Dispense', command: 'DISPENSE_FOOD' },
    { name: 'Water Dispense', command: 'DISPENSE_WATER' },
    { name: 'Both Dispense', command: 'DISPENSE_BOTH' },
    { name: 'Add Schedule', command: 'ADD_SCHEDULE:8,30,AM,food' }
  ];
  
  function runNextTest() {
    if (testNumber >= tests.length) {
      console.log('\n=================================');
      console.log('All Tests Completed!');
      console.log('=================================');
      console.log('\nPress Ctrl+C to exit');
      return;
    }
    
    const test = tests[testNumber];
    console.log(`\nTest ${testNumber + 1}: ${test.name}`);
    console.log(`→ Sending: ${test.command}`);
    
    port.write(test.command + '\n', (err) => {
      if (err) {
        console.error('❌ Error sending command:', err.message);
      }
    });
    
    testNumber++;
    setTimeout(runNextTest, 5000); // Wait 5 seconds between tests
  }
  
  runNextTest();
}

// Handle exit
process.on('SIGINT', () => {
  console.log('\n\nClosing connection...');
  process.exit(0);
});
