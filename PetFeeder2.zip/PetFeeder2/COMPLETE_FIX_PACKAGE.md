# Complete Fix Package - Copy These Files EXACTLY

## Summary

You need to replace **3 JavaScript files** on your Raspberry Pi and **re-upload the Arduino code**.

---

## File 1: `serial/arduinoSerial.js` 

**Location on Pi:** `/home/pi/PetFeeder2/serial/arduinoSerial.js`

**Critical line to find (around line 220):**
Look for the `handleDispenseComplete` function

**The line should be EXACTLY:**
```javascript
const source = this.currentCommand ? 'manual' : 'schedule';
```

**NOT:**
```javascript
const source = this.currentCommand ? 'manual' : 'scheduled';  // WRONG!
```

---

## File 2: `routes/user.js`

**Location on Pi:** `/home/pi/PetFeeder2/routes/user.js`

**In the `router.post('/schedules', ...)` function, ADD this after `const db = req.app.locals.db;`:**

```javascript
const arduinoSerial = require('../serial/arduinoSerial');
```

**Then AFTER the system log INSERT and BEFORE the broadcast, ADD:**

```javascript
// Sync to Arduino
if (arduinoSerial.isConnected()) {
  arduinoSerial.sendScheduleToArduino(hour, minute, ampm, dispense_type)
    .then(() => {
      console.log(`✓ Schedule synced to Arduino: ${hour}:${minute} ${ampm}`);
    })
    .catch(err => {
      console.error('Failed to sync schedule to Arduino:', err.message);
    });
} else {
  console.warn('Arduino not connected - schedule not synced');
}
```

---

## File 3: `user/user.js`

**Location on Pi:** `/home/pi/PetFeeder2/user/user.js`

**In the `initializeSocket()` function, BEFORE the closing `}`, ADD:**

```javascript
// Listen for feeding logs (real-time history update)
socket.on('feeding-logged', (data) => {
  console.log('[Feeding Logged]:', data);
  
  // Refresh dashboard to show latest feeding
  if (currentSection === 'home') {
    loadDashboard();
  }
  
  // Refresh history if on history page
  if (currentSection === 'history') {
    loadHistory();
  }
});
```

---

## File 4: `pet_feeder.ino` (Arduino)

**In the `addSchedule()` function, AFTER `saveScheduleToEEPROM(slot);` ADD:**

```cpp
// Send notification to Raspberry Pi
Serial.print(F("SCHEDULE_ADDED:"));
Serial.print(hour);
Serial.print(F(","));
Serial.print(minute);
Serial.print(F(","));
Serial.print(isPM ? F("PM") : F("AM"));
Serial.print(F(","));
if (mode == MODE_FOOD) Serial.println(F("food"));
else if (mode == MODE_WATER) Serial.println(F("water"));
else Serial.println(F("both"));
```

---

## VERIFICATION CHECKLIST

After making changes, check your Raspberry Pi server console for these messages:

### When you manually dispense:
```
✓ Feeding logged: food (manual) - success
```

### When you create a web schedule:
```
✓ Schedule synced to Arduino: 12:07 PM
Command sent to Arduino: ADD_SCHEDULE:12,7,PM,food
```

### When you add Arduino keypad schedule:
```
[Arduino] Keypad schedule: 8:30 AM food
✓ Arduino schedule saved to database (ID: X)
```

### When feeding happens:
```
Arduino: FOOD_DONE
✓ Feeding logged: food (schedule) - success
```

---

## TESTING PROCEDURE

### Test 1: Manual Dispense Dashboard Update
1. Open user dashboard in browser
2. Open browser console (F12)
3. Click "Feed Food Now"
4. **Watch console** - Should see: `[Feeding Logged]: {...}`
5. **Watch "Last Feeding"** - Should update within 2 seconds

**If it doesn't work:**
- Check browser console for `[Feeding Logged]` message
- Check if Socket.IO is connected (green dot)
- Check server console for `✓ Feeding logged` message

### Test 2: Web Schedule to Arduino
1. Create schedule for 2 minutes from now
2. **Check server console** - Should see: `✓ Schedule synced to Arduino`
3. **Check Arduino LCD** - Press 'B' to view schedules, should show your schedule
4. **Wait for scheduled time** - Servo should move

**If it doesn't work:**
- Check server console for "Failed to sync" error
- Check if Arduino is connected: `curl http://localhost:3000/api/arduino/status`
- Manually test: `curl -X POST http://localhost:3000/api/arduino/sync-schedule -H "Content-Type: application/json" -d '{"hour":12,"minute":30,"ampm":"PM","dispense_type":"food"}'`

### Test 3: Arduino Keypad to Website
1. On Arduino, press 'A'
2. Enter schedule: 3:30 PM, Food
3. **Check server console** - Should see: `[Arduino] Keypad schedule: 3:30 PM food`
4. **Check website schedules** - Should appear immediately without refresh

**If it doesn't work:**
- Open Arduino Serial Monitor, press 'A', add schedule
- Look for `SCHEDULE_ADDED:3,30,PM,food` message
- If not there, Arduino code wasn't uploaded
- If there, check server console for parsing errors

### Test 4: History Display
1. Do a manual feed
2. Go to History page
3. Should see the feeding log immediately

**If it doesn't work:**
- Check if feeding_logs table has data: `sqlite3 database/petfeeder.db "SELECT * FROM feeding_logs ORDER BY timestamp DESC LIMIT 5;"`
- Check for SQLITE_CONSTRAINT errors in server console
- Verify source column is 'manual' not 'scheduled'

---

## COMMON ERRORS AND FIXES

### Error: "SQLITE_CONSTRAINT: CHECK constraint failed"
**Cause:** Using 'scheduled' instead of 'schedule'  
**Fix:** Change line in `serial/arduinoSerial.js`:
```javascript
const source = this.currentCommand ? 'manual' : 'schedule';  // Must be 'schedule'
```

### Error: "Cannot read property 'sendScheduleToArduino' of undefined"
**Cause:** Missing `const arduinoSerial = require('../serial/arduinoSerial');`  
**Fix:** Add require statement at top of schedule creation function in `routes/user.js`

### Error: Arduino doesn't show web schedules
**Cause:** Schedule not being sent to Arduino  
**Fix:** Check if `arduinoSerial.isConnected()` returns true  
**Debug:** Add console.log before the if statement:
```javascript
console.log('Arduino connected?', arduinoSerial.isConnected());
```

### Error: Website doesn't show Arduino schedules
**Cause:** Arduino not sending SCHEDULE_ADDED message  
**Fix:** Re-upload Arduino code, test in Serial Monitor

---

## FILES TO COPY TO RASPBERRY PI

You need to copy these 3 files from Windows to Raspberry Pi:

1. `user/user.js`
2. `routes/user.js`
3. `serial/arduinoSerial.js`

### Method 1: SCP (from Windows CMD/PowerShell)
```bash
scp C:\Users\jhea\OneDrive\Desktop\Techno\PetFeeder2\user\user.js pi@raspberrypi.local:/home/pi/PetFeeder2/user/
scp C:\Users\jhea\OneDrive\Desktop\Techno\PetFeeder2\routes\user.js pi@raspberrypi.local:/home/pi/PetFeeder2/routes/
scp C:\Users\jhea\OneDrive\Desktop\Techno\PetFeeder2\serial\arduinoSerial.js pi@raspberrypi.local:/home/pi/PetFeeder2/serial/
```

### Method 2: WinSCP (GUI)
1. Connect to Raspberry Pi
2. Navigate to `/home/pi/PetFeeder2/`
3. Drag and drop the 3 files

### Method 3: Manual Edit
SSH into Pi and edit each file with nano following the instructions above

---

## FINAL CHECKLIST

- [ ] Copied `user/user.js` to Pi
- [ ] Copied `routes/user.js` to Pi  
- [ ] Copied `serial/arduinoSerial.js` to Pi
- [ ] Uploaded `pet_feeder.ino` to Arduino
- [ ] Restarted server on Pi (`npm start`)
- [ ] Cleared browser cache (Ctrl+Shift+Delete)
- [ ] Tested manual dispense → Dashboard updates?
- [ ] Tested web schedule → Arduino receives?
- [ ] Tested keypad schedule → Website shows?
- [ ] Tested history → Shows all feeds?

---

## IF STILL NOT WORKING

Send me the output of these commands:

```bash
# On Raspberry Pi
cd ~/PetFeeder2
grep -n "feeding-logged" user/user.js
grep -n "arduinoSerial.sendScheduleToArduino" routes/user.js  
grep -n "const source = " serial/arduinoSerial.js
```

And take a screenshot of:
1. Browser console (F12) when you click "Feed Now"
2. Server console output when you create a schedule
3. Arduino Serial Monitor when you press 'A' and add schedule

This will help me see exactly what's wrong.
