# Automated Pet Feeder with RTC Scheduling

## Overview
This Arduino-based pet feeder allows you to schedule automatic food and water dispensing at specific times using a 12-hour format with AM/PM. The system supports up to 6 feeding schedules with three dispensing modes: Food Only, Water Only, or Both.

## Features
- ✅ **12-Hour Time Format** with AM/PM display
- ✅ **Up to 6 Schedules** stored in EEPROM
- ✅ **Three Dispensing Modes**: Food Only, Water Only, or Both
- ✅ **Keypad Control** for easy schedule management
- ✅ **LCD Display** showing current time and next schedule
- ✅ **Trigger Protection** prevents multiple executions
- ✅ **Persistent Storage** schedules saved across power cycles

## Hardware Requirements

### Components
- Arduino Uno/Nano
- DS3231 RTC Module
- 16x2 I2C LCD Display (0x27 address)
- 4x4 Matrix Keypad
- Servo Motor (for food dispensing)
- Water Pump with Driver/Relay Module
- External 5V Power Supply (for pump/servo if needed)
- Jumper wires

### Libraries Required
Install these libraries via Arduino Library Manager:
- `Wire` (built-in)
- `LiquidCrystal_I2C` by Frank de Brabander
- `RTClib` by Adafruit
- `Keypad` by Mark Stanley
- `Servo` (built-in)
- `EEPROM` (built-in)

## Wiring Diagram

### Servo Motor
```
Servo GND   → Arduino GND
Servo VCC   → Arduino 5V (or external 5V)
Servo Signal → Arduino Pin 10
```

### Water Pump Module
```
Pump GND    → Arduino GND
Pump VCC    → External Power Supply (as needed)
Pump Signal → Arduino Pin 11
```

### 4x4 Keypad
```
Row 1 → Arduino Pin 2
Row 2 → Arduino Pin 3
Row 3 → Arduino Pin 4
Row 4 → Arduino Pin 5
Col 1 → Arduino Pin 6
Col 2 → Arduino Pin 7
Col 3 → Arduino Pin 8
Col 4 → Arduino Pin 9
```

### I2C LCD Display (16x2)
```
LCD SDA → Arduino A4
LCD SCL → Arduino A5
LCD VCC → Arduino 5V
LCD GND → Arduino GND
```

### RTC Module (DS3231)
```
RTC SDA → Arduino A4 (shared with LCD)
RTC SCL → Arduino A5 (shared with LCD)
RTC VCC → Arduino 5V
RTC GND → Arduino GND
```

## Keypad Layout
```
┌───┬───┬───┬───┐
│ 1 │ 2 │ 3 │ A │  A = Add Schedule
├───┼───┼───┼───┤
│ 4 │ 5 │ 6 │ B │  B = View Schedules
├───┼───┼───┼───┤
│ 7 │ 8 │ 9 │ C │  C = Delete Schedule
├───┼───┼───┼───┤
│ * │ 0 │ # │ D │  D = Clear All
└───┴───┴───┴───┘
  *=Cancel  #=Confirm
```

## How to Use

### Main Display
The LCD continuously shows:
- **Line 1**: Current time (e.g., "8:01:30 AM")
- **Line 2**: Next scheduled action (e.g., "Next: 8:00 AM F")
  - F = Food
  - W = Water
  - B = Both

### Adding a Schedule (Press A)

1. **Press A** to start adding a schedule
2. **Enter Hour (1-12)**: Type 1 or 2 digits, press **#**
3. **Enter Minute (00-59)**: Type 2 digits, press **#**
4. **Select AM/PM**:
   - Press **1** for AM
   - Press **2** for PM
5. **Select Mode**:
   - Press **1** for Food Only
   - Press **2** for Water Only
   - Press **3** for Food and Water
6. LCD confirms: "8:00 AM Food Added!"

**Note**: Press **\*** at any step to cancel

### Viewing Schedules (Press B)

1. **Press B** to view all saved schedules
2. Each schedule displays for 2 seconds:
   ```
   1. 8:00 AM
   FOOD
   ```
3. Cycles through all active schedules

### Deleting a Schedule (Press C)

1. **Press C** to delete a schedule
2. **Enter schedule number (1-6)**, press **#**
3. LCD confirms: "Schedule Deleted!"
