# Issues Summary and Fixes

## Files Modified in This Session (Context Transfer)

### Already Fixed:
1. **`pet_feeder.ino`** - Arduino code
   - Fixed baud rate (9600 → 115200)
   - Fixed RTC blocking issue
   - Added debug messages
   - Added TEST_SERVO command

2. **`ARDUINO_FIXES.md`** - New documentation
3. **`TROUBLESHOOTING_NO_RESPONSE.md`** - New documentation  
4. **`SERVO_TROUBLESHOOTING.md`** - New documentation

---

## Current Issues to Fix

### Issue 1: User Dashboard Not Updating on Dispense ❌
**Problem:** When food is dispensed, the user dashboard doesn't show real-time updates.

**Root Cause:**
- `arduinoSerial.js` emits `dispense-complete` event ✅
- But `user.js` frontend doesn't listen to Socket.IO events ❌

**Fix Needed:**
- Add Socket.IO listener in `user/user.js` to update dashboard in real-time

---

### Issue 2: Web Schedule Not Syncing to Arduino ❌
**Problem:** When schedule is created on website (12:07 PM), Arduino doesn't receive it.

**Root Cause Analysis:**

**Step 1: Schedule Creation** ✅
- User creates schedule on website
- Saved to database successfully
- Socket.IO broadcasts `schedule-created` event

**Step 2: Sync to Arduino** ❌
- Schedule is NOT automatically sent to Arduino
- `routes/user.js` creates schedule but doesn't call Arduino sync
- Arduino never receives `ADD_SCHEDULE:` command

**Why Arduino Doesn't Dispense:**
- Arduino only knows about schedules stored in its own EEPROM
- Web schedules exist only in SQLite database
- No bridge between database schedules and Arduino EEPROM

**Fix Needed:**
1. When schedule is created on website → send to Arduino immediately
2. Create periodic sync to keep Arduino schedules in sync with database
3. Arduino needs to store web schedules in EEPROM

---

### Issue 3: Arduino/Keypad Schedules Not Showing on Website ❌
**Problem:** When schedule is added via keypad (physical), it doesn't appear on website.

**Root Cause:**
- Arduino stores schedule in EEPROM ✅
- Arduino doesn't send notification to Raspberry Pi ❌
- No sync mechanism from Arduino → Database

**Current Arduino Code:**
```cpp
void addSchedule() {
  // ... get user input via keypad ...
  
  // Save to EEPROM ✅
  schedules[slot].active = true;
  saveScheduleToEEPROM(slot);
  
  // Display confirmation ✅
  lcd.print(F("Food Added!"));
  
  // ❌ MISSING: Send to Raspberry Pi
  // Serial.println("SCHEDULE_ADDED:8,30,AM,food");
}
```

**Fix Needed:**
1. Arduino sends `SCHEDULE_ADDED:` message after keypad schedule creation
2. RPi receives message and saves to database
3. Socket.IO broadcasts update to all connected clients

---

### Issue 4: Feeding History Not Showing/Working ❌
**Problem:** Feeding history is empty or not displaying.

**Possible Root Causes:**

**A. Database Query Issue:**
```javascript
// In routes/user.js line 251
router.get('/feeding-history', (req, res) => {
  const userId = req.session.user.id;
  // Query filters by user_id
  db.all(`SELECT * FROM feeding_logs WHERE user_id = ? ...`, [userId], ...)
});
```

**Issue:** If `feeding_logs.user_id` is NULL when Arduino auto-dispenses, history won't show.

**B. Frontend Not Fetching:**
- `user/user.js` might not be calling `/api/user/feeding-history`
- Or frontend HTML might not have history display section

**C. No Data Being Logged:**
- Manual dispense logs correctly (includes userId) ✅
- Arduino auto-dispense doesn't have userId ❌
- Scheduled dispense needs to include user association

**Fix Needed:**
1. Ensure all dispense actions log to `feeding_logs`
2. Associate scheduled dispenses with correct user
3. Frontend must fetch and display history
4. Add Socket.IO real-time update when new feed log is created

---

## Detailed Fix Plan

### Fix 1: Real-time Dashboard Updates

**File: `user/user.js`**
Add Socket.IO listeners:
```javascript
// Listen for dispense completion
socket.on('dispense-complete', function(data) {
  // Update last feeding display
  // Refresh dashboard stats
  loadDashboard();
});

// Listen for new feeding log
socket.on('feeding-logged', function(data) {
  // Append to history list
  // Update feed count
});
```

---

### Fix 2: Sync Web Schedules to Arduino

**File: `routes/user.js`**
In schedule creation endpoint:
```javascript
router.post('/schedules', (req, res) => {
  // ... save to database ...
  
  // NEW: Sync to Arduino
  const arduinoSerial = require('../serial/arduinoSerial');
  arduinoSerial.sendScheduleToArduino(hour, minute, ampm, dispense_type)
    .then(() => {
      console.log('Schedule synced to Arduino');
    })
    .catch(err => {
      console.error('Failed to sync to Arduino:', err);
    });
});
```

**File: `serial/arduinoSerial.js`**
Add periodic sync function:
```javascript
// Every hour, sync active schedules to Arduino
setInterval(() => {
  if (this.connected && this.db) {
    this.syncSchedulesToArduino();
  }
}, 3600000); // 1 hour

syncSchedulesToArduino() {
  this.db.all('SELECT * FROM schedules WHERE is_active = 1 LIMIT 6', (err, schedules) => {
    schedules.forEach(schedule => {
      this.sendScheduleToArduino(
        schedule.hour, 
        schedule.minute, 
        schedule.ampm, 
        schedule.dispense_type
      );
    });
  });
}
```

---

### Fix 3: Arduino Keypad Schedules → Website

**File: `pet_feeder.ino`**
Modify `addSchedule()` function:
```cpp
void addSchedule() {
  // ... existing code to get user input ...
  
  // Save to EEPROM
  schedules[slot].active = true;
  saveScheduleToEEPROM(slot);
  
  // NEW: Notify Raspberry Pi
  Serial.print(F("SCHEDULE_ADDED:"));
  Serial.print(schedules[slot].hour);
  Serial.print(F(","));
  Serial.print(schedules[slot].minute);
  Serial.print(F(","));
  Serial.print(schedules[slot].isPM ? F("PM") : F("AM"));
  Serial.print(F(","));
  if (schedules[slot].mode == MODE_FOOD) Serial.println(F("food"));
  else if (schedules[slot].mode == MODE_WATER) Serial.println(F("water"));
  else Serial.println(F("both"));
}
```

**File: `serial/arduinoSerial.js`**
Handle Arduino schedule notifications:
```javascript
handleArduinoResponse(response) {
  // ... existing code ...
  
  // NEW: Handle schedule added from keypad
  if (response.startsWith('SCHEDULE_ADDED:')) {
    const params = response.substring(15); // Remove "SCHEDULE_ADDED:"
    const [hour, minute, ampm, type] = params.split(',');
    
    // Save to database (associate with admin or default user)
    this.db.run(
      `INSERT INTO schedules (user_id, hour, minute, ampm, dispense_type, is_active, source) 
       VALUES (1, ?, ?, ?, ?, 1, 'arduino')`,
      [hour, minute, ampm, type]
    );
    
    // Broadcast to web clients
    if (this.io) {
      this.io.emit('schedule-created', { 
        source: 'arduino',
        hour, minute, ampm, dispense_type: type
      });
    }
  }
}
```

---

### Fix 4: Feeding History Display

**A. Ensure Logging for All Dispense Types**

**File: `serial/arduinoSerial.js`**
```javascript
handleDispenseComplete(type, status) {
  // For Arduino auto-dispense, use admin user (id=1)
  const userId = this.currentCommand ? this.currentCommand.userId : 1;
  
  // Log to database
  if (this.db && type) {
    this.db.run(
      `INSERT INTO feeding_logs (user_id, dispense_type, source, status) 
       VALUES (?, ?, ?, ?)`,
      [userId, type, 'scheduled', status], // Mark as 'scheduled' if no current command
      (err) => {
        if (err) console.error('Error logging dispense:', err);
        
        // Broadcast new log to clients
        if (this.io) {
          this.io.emit('feeding-logged', { 
            userId, type, source: 'scheduled', status, timestamp: new Date() 
          });
        }
      }
    );
  }
}
```

**B. Frontend Display**

**File: `user/user.js`**
```javascript
// Fetch feeding history
function loadFeedingHistory(filter = 'all') {
  fetch(`/api/user/feeding-history?filter=${filter}`)
    .then(res => res.json())
    .then(data => {
      if (data.success) {
        displayHistory(data.logs);
      }
    });
}

// Listen for new feeding logs
socket.on('feeding-logged', function(data) {
  loadFeedingHistory(); // Refresh history
});
```

---

## Priority Order

1. **Fix 1** (Dashboard updates) - Quick fix, improves UX
2. **Fix 4** (History display) - Essential feature
3. **Fix 2** (Web → Arduino sync) - Core functionality
4. **Fix 3** (Arduino → Web sync) - Nice to have

---

## Testing Checklist

After fixes:
- [ ] Manual dispense updates dashboard in real-time
- [ ] Feeding history shows all dispenses
- [ ] Web schedule syncs to Arduino
- [ ] Arduino dispenses at scheduled time
- [ ] Keypad schedule appears on website
- [ ] Socket.IO events broadcast correctly
- [ ] Multiple users see their own history
- [ ] Scheduled feeds log correctly

