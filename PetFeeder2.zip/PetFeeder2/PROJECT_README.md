# Pet Feeder System - Complete Setup Guide

## System Overview

This is a complete Pet Feeder System that runs on Raspberry Pi 4 and communicates with Arduino via USB Serial. The system provides:

- Web-based user interface
- Real-time updates via WebSockets
- Scheduled feeding with RTC
- Manual dispense controls
- User management
- Feeding logs and analytics
- Arduino serial communication

## Hardware Architecture

```
┌─────────────────┐
│  Web Browser    │
│  (Any Device)   │
└────────┬────────┘
         │ HTTP/WebSocket
         │
┌────────▼────────────────┐
│   Raspberry Pi 4        │
│  ┌──────────────────┐   │
│  │   Node.js Server │   │
│  │   SQLite DB      │   │
│  │   Socket.IO      │   │
│  └────────┬─────────┘   │
│           │ USB Serial   │
│  ┌────────▼─────────┐   │
│  │   Arduino Nano   │   │
│  │  - Servo (Food)  │   │
│  │  - Pump (Water)  │   │
│  │  - RTC Module    │   │
│  │  - LCD Display   │   │
│  │  - Keypad        │   │
│  └──────────────────┘   │
└─────────────────────────┘
```

## Technology Stack

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Backend**: Node.js, Express.js
- **Database**: SQLite3
- **Real-time**: Socket.IO
- **Authentication**: Express Session + bcrypt
- **Serial Communication**: SerialPort package
- **Hardware**: Raspberry Pi 4, Arduino Nano

## Installation Steps

### 1. Raspberry Pi Setup

```bash
# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Install Node.js (v18 or higher)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version
npm --version

# Install build tools for native modules
sudo apt-get install -y build-essential

# Install Git
sudo apt-get install -y git
```

### 2. Project Setup

```bash
# Create project directory
cd ~
mkdir pet-feeder-system
cd pet-feeder-system

# Clone or copy project files here
# (Copy all project files to this directory)

# Install dependencies
npm install

# Initialize database
node database/init.js
```

### 3. Arduino USB Connection

```bash
# Find Arduino USB port
ls /dev/tty*

# Common ports:
# /dev/ttyUSB0 (USB to Serial)
# /dev/ttyACM0 (Arduino Uno/Nano)

# Give permission to access serial port
sudo usermod -a -G dialout $USER
sudo chmod 666 /dev/ttyUSB0

# Reboot for permissions to take effect
sudo reboot
```

### 4. Arduino Code Upload

1. Open Arduino IDE on your computer
2. Install required libraries:
   - Wire
   - LiquidCrystal_I2C
   - RTClib
   - Keypad
   - Servo
3. Open `pet_feeder.ino`
4. Select board: Arduino Nano
5. Select correct COM port
6. Upload code to Arduino
7. Connect Arduino to Raspberry Pi via USB

### 5. Start the Server

```bash
# Start server
npm start

# Or with nodemon for development
npm run dev
```

### 6. Access the System

#### From Raspberry Pi:
```
http://localhost:3000
```

#### From Other Devices on Same Network:
```
http://<raspberry-pi-ip>:3000
```

To find Raspberry Pi IP:
```bash
hostname -I
```

Example: `http://192.168.1.100:3000`

## Default Login Credentials

### Admin Account
- **Username**: `admin`
- **Password**: `admin123`

**⚠️ Important**: Change the admin password immediately after first login!

## Project Structure

```
PetFeederSystem/
├── server.js                 # Main server file
├── package.json              # Dependencies
├── index.html                # Login page
│
├── database/
│   ├── init.js              # Database initialization
│   └── petfeeder.db         # SQLite database (created automatically)
│
├── routes/
│   ├── auth.js              # Authentication routes
│   ├── admin.js             # Admin routes
│   ├── user.js              # User routes
│   └── api.js               # Arduino API routes
│
├── middleware/
│   ├── authMiddleware.js    # Authentication middleware
│   └── adminMiddleware.js   # Admin authorization
│
├── serial/
│   └── arduinoSerial.js     # Arduino serial communication
│
├── admin/
│   ├── admin.html           # Admin dashboard
│   ├── admin.css            # Admin styles
│   └── admin.js             # Admin JavaScript
│
├── user/
│   ├── user.html            # User dashboard
│   ├── user.css             # User styles
│   └── user.js              # User JavaScript
│
└── public/
    ├── css/
    ├── js/
    └── assets/
```

## Arduino Commands

The backend sends these commands to Arduino:

- `DISPENSE_FOOD` - Dispense food only
- `DISPENSE_WATER` - Dispense water only
- `DISPENSE_BOTH` - Dispense both food and water
- `GET_STATUS` - Request Arduino status

Arduino responses:

- `FOOD_DONE` - Food dispensing complete
- `WATER_DONE` - Water dispensing complete
- `BOTH_DONE` - Both dispensing complete
- `STATUS_ONLINE` - Arduino is online
- `ERROR` - Error occurred

## Database Tables

1. **users** - User accounts and profiles
2. **schedules** - Feeding schedules
3. **feeding_logs** - History of all feedings
4. **commands** - Command history
5. **notifications** - User notifications
6. **device_status** - Arduino/RPi status
7. **system_logs** - System event logs
8. **user_settings** - User preferences
9. **system_settings** - System configuration

## Port Configuration

- **Default Port**: 3000
- **Serial Port**: /dev/ttyUSB0 (auto-detected)
- **Serial Baud Rate**: 115200

To change the port, edit `server.js`:
```javascript
const PORT = process.env.PORT || 3000;
```

## Auto-Start on Boot (Optional)

Create systemd service:

```bash
sudo nano /etc/systemd/system/petfeeder.service
```

Add:
```ini
[Unit]
Description=Pet Feeder System
After=network.target

[Service]
Type=simple
User=pi
WorkingDirectory=/home/pi/pet-feeder-system
ExecStart=/usr/bin/node server.js
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable petfeeder.service
sudo systemctl start petfeeder.service
sudo systemctl status petfeeder.service
```

## Troubleshooting

### Arduino Not Connecting

1. Check USB connection
2. Verify port permissions:
   ```bash
   ls -l /dev/ttyUSB0
   sudo chmod 666 /dev/ttyUSB0
   ```
3. Check if port is correct in `serial/arduinoSerial.js`
4. Restart server

### Cannot Access from Other Devices

1. Check firewall:
   ```bash
   sudo ufw allow 3000
   ```
2. Verify Raspberry Pi IP:
   ```bash
   hostname -I
   ```
3. Ensure devices are on same network

### Database Errors

```bash
# Reinitialize database
rm database/petfeeder.db
node database/init.js
```

### Port Already in Use

```bash
# Find process using port 3000
sudo lsof -i :3000

# Kill the process
sudo kill -9 <PID>
```

## Features

### Admin Dashboard
- User management (CRUD operations)
- System statistics
- Feeding logs
- Device monitoring
- System settings
- Real-time updates

### User Dashboard
- Manual dispense controls
- Schedule management
- Feeding history
- Pet profile
- Settings (theme, notifications)
- Real-time status updates

### Arduino Features
- Multiple feeding schedules (up to 6)
- 12-hour time format with AM/PM
- Three dispense modes (Food, Water, Both)
- LCD display
- Keypad controls
- EEPROM storage

## Security

- Passwords hashed with bcrypt
- Session-based authentication
- Role-based access control (Admin/User)
- SQL injection prevention
- Input validation

## Performance

- WebSocket for real-time updates
- Database indexing
- Efficient serial communication
- Session management
- Connection pooling

## Support

For issues or questions:
1. Check troubleshooting section
2. Review system logs
3. Check Arduino serial monitor
4. Verify database integrity

## License

MIT License - See LICENSE file

## Credits

Developed as a Capstone Project
- Raspberry Pi 4
- Arduino Nano
- Node.js + Express
- SQLite3
- Socket.IO
