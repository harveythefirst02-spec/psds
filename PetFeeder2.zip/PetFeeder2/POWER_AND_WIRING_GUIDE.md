# Pet Feeder System - Power & Wiring Guide

## ⚡ CRITICAL: Power Supply Architecture

### ⚠️ DO NOT Power Motors from Arduino or Raspberry Pi!

**Common Mistake:** Connecting servo and pump directly to Arduino 5V pin
**Problem:** Motors draw too much current and will crash or damage boards
**Solution:** Use separate dedicated power supply for motors

---

## 🔌 Power Distribution Overview

```
┌──────────────────────────────────────────────────────────────┐
│                    COMPLETE POWER SETUP                      │
└──────────────────────────────────────────────────────────────┘

Component 1: RASPBERRY PI 4
├─ Power Source: 5V 3A USB-C/Micro-USB Power Adapter
├─ Powers: Raspberry Pi board only
└─ Connection: Wall outlet → Adapter → RPi power port


Component 2: ARDUINO UNO (Logic)
├─ Option A (Simple): USB Cable from Raspberry Pi
│  └─ RPi USB port → Arduino USB port
│     Powers: Arduino microcontroller (logic circuits)
│     Also provides: Data communication
│
└─ Option B (More Stable): Separate 5V Adapter
   └─ 5V 1A DC Adapter → Arduino barrel jack (2.1mm)
      Plus USB cable for data only


Component 3: MOTORS (CRITICAL - SEPARATE POWER!)
├─ Power Source: 5V 2-3A DC Power Supply (DEDICATED)
│
├─ Option A: DC Power Adapter with Breadboard Power Module
│  └─ Wall outlet → 5V 3A Adapter → Breadboard power rail
│     └─→ Servo Motor VCC
│     └─→ Relay Module VCC → Water Pump
│
├─ Option B: Battery Pack (Portable)
│  └─ 4x AA Battery Holder (6V) → Breadboard
│     └─→ Motors as above
│
└─ Option C: USB Power Bank
   └─ Power bank → USB to DC barrel jack cable → Breadboard
      └─→ Motors as above


⚠️ CRITICAL: COMMON GROUND CONNECTION
All grounds MUST be connected together:
└─→ Arduino GND ↔ Motor Power Supply GND ↔ RPi GND (optional)
    This allows Arduino control signals to work properly!
```

---

## 🔧 Detailed Component Wiring

### 1. Raspberry Pi 4 Power

```
Wall Outlet
    │
    ├─→ [5V 3A USB-C Power Adapter]
            │
            └─→ Raspberry Pi 4 USB-C Port
                │
                └─→ Powers entire RPi board
```

**Specifications:**
- Voltage: 5V DC
- Current: Minimum 3A (3000mA)
- Connector: USB-C (RPi 4) or Micro-USB (RPi 3)
- Power: 15W

**Recommended Adapters:**
- Official Raspberry Pi Power Supply
- Any quality 5V 3A USB-C charger
- Avoid cheap generic adapters (cause instability)

---

### 2. Arduino Uno Power & Communication

#### Option A: USB Power from Raspberry Pi (Simple Setup)

```
Raspberry Pi 4
    │
    └─→ USB Type-A Port
            │
            └─→ [USB A to USB B Cable]
                    │
                    └─→ Arduino USB Port
                         ├─→ Powers Arduino (max 500mA)
                         └─→ Data communication (Serial)
```

**Pros:**
- Simple, one cable
- Communication + power combined
- Easy to set up

**Cons:**
- RPi USB port limited to 500-1200mA
- Can cause undervoltage if RPi is busy
- Not recommended for long-term stability

#### Option B: Separate Arduino Power (Recommended)

```
Wall Outlet                    Raspberry Pi 4
    │                               │
    ├─→ [5V 1A DC Adapter]         └─→ USB Port
         (2.1mm barrel jack)             │
              │                          │
              └─→ Arduino Barrel Jack    └─→ [USB Cable (data only)]
                  (Powers Arduino)              │
                                                └─→ Arduino USB Port
                                                    (Communication only)
```

**Pros:**
- Stable power for Arduino
- Isolates power from RPi
- Recommended for 24/7 operation

**Specs:**
- Voltage: 7-12V DC (regulated internally to 5V)
- Current: 500mA minimum
- Connector: 2.1mm center-positive barrel jack

---

### 3. Servo Motor Power (CRITICAL!)

```
Wall Outlet
    │
    └─→ [5V 3A DC Power Supply]
            │
            └─→ [Breadboard Power Module] OR [Power Rail]
                    │
                    ├─→ VCC Rail (Red/+)
                    └─→ GND Rail (Blue/Black/-)

From VCC Rail:
    └─→ Servo Motor RED wire (VCC)

From GND Rail:
    └─→ Servo Motor BROWN/BLACK wire (GND)

From Arduino Pin 10:
    └─→ Servo Motor ORANGE/YELLOW wire (Signal)

⚠️ CONNECT GROUNDS:
Arduino GND pin → Breadboard GND Rail
```

**Servo Specifications (SG90 typical):**
- Operating Voltage: 4.8V - 6V
- Idle Current: 10-20mA
- **Active Current: 200-500mA**
- **Stall Current: 800-1200mA** ← Can crash Arduino!
- Torque: 1.8kg-cm (4.8V)

**Why Separate Power:**
- Arduino 5V pin can only provide ~400mA total
- Servo can draw 1A during movement
- Voltage drops cause Arduino resets
- Separate supply prevents crashes

---

### 4. Water Pump Power (CRITICAL!)

```
Wall Outlet
    │
    └─→ [5V 3A DC Power Supply] (Same as servo)
            │
            └─→ Breadboard Power Rail
                    │
                    ├─→ VCC Rail → Relay Module VCC
                    └─→ GND Rail → Relay Module GND

Relay Module Connections:
├─ VCC → Breadboard VCC (5V)
├─ GND → Breadboard GND
├─ IN  → Arduino Pin 11 (Control Signal)
│
└─ Relay Switch:
    ├─ COM → Power Supply VCC (5V)
    ├─ NO  → Water Pump (+)
    └─ NC  → (Not connected)

Water Pump:
├─ (+) → Relay NO (Normally Open)
└─ (-) → Power Supply GND

⚠️ CONNECT GROUNDS:
Arduino GND → Relay GND → Power Supply GND → Pump GND
```

**Water Pump Specifications:**
- Operating Voltage: 3V - 6V
- Current: 100-300mA (running)
- Flow Rate: 1-2 L/min
- Type: Submersible DC pump

**Why Use Relay:**
- Isolates Arduino from motor noise
- Protects Arduino from back EMF
- Can handle higher current
- Safer switching

**Relay Module Specs:**
- Coil Voltage: 5V
- Trigger: Low-level (active LOW)
- Contact Rating: 10A 250VAC / 10A 30VDC
- Isolation: Optical

---

## 📊 Complete Wiring Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    POWER & SIGNAL CONNECTIONS                    │
└─────────────────────────────────────────────────────────────────┘

RASPBERRY PI 4                    ARDUINO UNO
┌─────────────────┐              ┌────────────────┐
│                 │              │                │
│  Power In       │              │  USB Port      │←──┐
│  (USB-C 5V 3A) ←┼──[Adapter]  │    ↕ Data      │   │
│                 │              │                │   │
│  USB Port       │              │  Pin 10 ──────┼───┼──→ Servo Signal (Orange)
│    ↕            │──[USB Cable]→│  Pin 11 ──────┼───┼──→ Relay IN (Control)
│  (Data Only)    │              │                │   │
│                 │              │  5V  ──────────┼───┼──X (DO NOT USE!)
│                 │              │  GND ──────────┼───┼──→ Common GND
│                 │              │                │   │
└─────────────────┘              └────────────────┘   │
                                                      │
                                                      │
MOTOR POWER SUPPLY                                    │
┌─────────────────┐                                   │
│                 │                                   │
│  5V 3A Adapter  │                                   │
│  (Wall Plug)    │                                   │
│                 │                                   │
│  Output:        │                                   │
│  ├─ VCC (5V) ───┼──→ Breadboard VCC Rail ─────────┐│
│  └─ GND (0V) ───┼──→ Breadboard GND Rail ─────────┼┘
│                 │                                  │
└─────────────────┘                                  │
                                                     │
BREADBOARD POWER RAILS                               │
┌────────────────────────────────┐                   │
│                                │                   │
│  VCC Rail (Red +)              │                   │
│    ├──→ Servo VCC (Red wire)   │                   │
│    └──→ Relay VCC              │                   │
│                                │                   │
│  GND Rail (Black -)            │                   │
│    ├──→ Servo GND (Brown)      │                   │
│    ├──→ Relay GND              │                   │
│    ├──→ Pump GND (via relay)   │                   │
│    └──→ Arduino GND ───────────┼───────────────────┘
│                                │
└────────────────────────────────┘

SERVO MOTOR (SG90)           WATER PUMP + RELAY
┌─────────────┐              ┌──────────────────┐
│             │              │  Relay Module    │
│  Red    → VCC (Breadboard) │  ┌────────────┐  │
│  Brown  → GND (Breadboard) │  │ VCC ← 5V   │  │
│  Orange → Pin 10 (Arduino) │  │ GND ← GND  │  │
│             │              │  │ IN  ← Pin11│  │
└─────────────┘              │  │            │  │
                             │  │ COM ← 5V   │  │
                             │  │ NO  → Pump+│  │
                             │  │ NC         │  │
                             │  └────────────┘  │
                             │                  │
                             │  Pump Wire:      │
                             │  (+) → Relay NO  │
                             │  (-) → GND       │
                             └──────────────────┘

⚠️  CRITICAL CONNECTIONS:
1. All GND must be connected together (common ground)
2. Servo/Pump VCC from external supply (NOT Arduino)
3. Only control signals from Arduino (Pins 10, 11)
```

---

## 🛒 Shopping List - Power Components

### Essential Power Supplies

**1. Raspberry Pi Power Supply**
- Item: 5V 3A USB-C Power Adapter (RPi 4) or Micro-USB (RPi 3)
- Specs: 5V DC, 3000mA, USB-C connector
- Price: $8-15
- Example: Official Raspberry Pi Power Supply

**2. Motor Power Supply (REQUIRED)**
- Item: 5V 3A DC Power Adapter
- Specs: 5V DC, 2000-3000mA, 2.1mm barrel jack
- Price: $6-12
- Alternative: 6V 2A power supply

**3. Arduino Power (Optional but Recommended)**
- Item: 7-12V DC Adapter
- Specs: 9V DC, 500mA, 2.1mm barrel jack center-positive
- Price: $5-10

### Power Distribution Components

**4. Breadboard Power Module**
- Item: MB102 Breadboard Power Supply Module
- Features: 
  - Accepts 6.5-12V DC input
  - Outputs 5V and 3.3V regulated
  - Fits standard breadboard
- Price: $2-5
- Quantity: 1

**5. Breadboard (if not already owned)**
- Item: Full-size breadboard (830 points)
- Price: $5-8
- Quantity: 1

**6. Jumper Wires**
- Item: Male-to-Male jumper wire kit
- Quantity: 40-pack
- Price: $5

### Motor Control Components

**7. Relay Module**
- Item: 5V 1-Channel Relay Module
- Specs: 
  - Coil: 5V
  - Contact: 10A
  - Optical isolation
- Price: $2-5
- Quantity: 1

**8. Servo Motor**
- Item: SG90 Micro Servo or similar
- Specs: 4.8-6V, 1.8kg-cm torque
- Price: $3-8
- Quantity: 1

**9. Water Pump**
- Item: Submersible DC Mini Water Pump
- Specs: 3-6V DC, 100-300mA
- Price: $5-10
- Quantity: 1

### Cables

**10. USB Cable (RPi to Arduino)**
- Item: USB A to USB B cable (1-2 meters)
- Price: $3-5

**11. DC Power Cables**
- Item: DC barrel jack extension cables
- Quantity: 2-3
- Price: $5-8 for pack

---

## ⚙️ Assembly Instructions

### Step 1: Set Up Breadboard Power

1. Insert breadboard power module into breadboard
2. Connect 5V 3A adapter to power module input
3. Set both rails to 5V (using jumpers on module)
4. Verify 5V output with multimeter

### Step 2: Connect Raspberry Pi

1. Connect 5V 3A USB-C adapter to Raspberry Pi
2. Connect USB A-to-B cable from RPi to Arduino
3. Do NOT power on yet

### Step 3: Connect Arduino

**If using separate Arduino power:**
1. Connect 9V adapter to Arduino barrel jack
2. Or rely on USB power from RPi

### Step 4: Connect Servo Motor

1. **Red wire** → Breadboard VCC rail (5V)
2. **Brown/Black wire** → Breadboard GND rail
3. **Orange/Yellow wire** → Arduino Pin 10

### Step 5: Connect Relay Module

1. **VCC** → Breadboard VCC rail (5V)
2. **GND** → Breadboard GND rail
3. **IN** → Arduino Pin 11
4. Verify relay clicks when Pin 11 goes LOW

### Step 6: Connect Water Pump

1. **Pump (+) wire** → Relay NO (Normally Open)
2. **Pump (-) wire** → Breadboard GND rail
3. **Relay COM** → Breadboard VCC rail (5V)

### Step 7: Common Ground (CRITICAL!)

1. Connect Arduino GND pin to breadboard GND rail
2. Use thick wire (22AWG or thicker)
3. Verify continuity with multimeter:
   - Arduino GND ↔ Breadboard GND ↔ Power supply GND

### Step 8: Power On Sequence

1. Connect motor power supply (breadboard) - turn ON
2. Connect Raspberry Pi power - turn ON
3. Arduino will power on via USB or its adapter
4. Check all LEDs:
   - RPi: Red power LED solid
   - Arduino: Power LED on
   - Relay: Indicator LED (may blink)

---

## 🧪 Testing Power Setup

### Test 1: Voltage Check

```bash
# Using multimeter
1. Set to DC voltage mode
2. Check breadboard VCC rail: Should read 4.8-5.2V
3. Check Arduino 5V pin: Should read 4.8-5.2V
4. Check servo VCC wire: Should read 4.8-5.2V
```

### Test 2: Servo Test (Arduino IDE)

```cpp
#include <Servo.h>
Servo servo;

void setup() {
  servo.attach(10);
}

void loop() {
  servo.write(0);
  delay(1000);
  servo.write(90);
  delay(1000);
}
```

**Expected:** Servo moves smoothly without Arduino resetting

### Test 3: Pump Test (Arduino IDE)

```cpp
#define PUMP_PIN 11

void setup() {
  pinMode(PUMP_PIN, OUTPUT);
  digitalWrite(PUMP_PIN, HIGH); // Relay off (active LOW)
}

void loop() {
  digitalWrite(PUMP_PIN, LOW);  // Turn pump ON
  delay(3000);
  digitalWrite(PUMP_PIN, HIGH); // Turn pump OFF
  delay(3000);
}
```

**Expected:** Pump runs without Arduino resetting

---

## 🔍 Troubleshooting Power Issues

### Issue 1: Arduino Keeps Resetting

**Symptoms:**
- Arduino restarts when servo moves
- Power LED dims/flickers
- LCD blanks out

**Causes:**
- Motors powered from Arduino 5V pin
- Insufficient power supply current
- No common ground

**Solutions:**
1. ✅ Use separate power supply for motors
2. ✅ Check power supply is rated 2-3A
3. ✅ Verify common ground connection
4. ✅ Add 100-470µF capacitor across motor power

### Issue 2: Servo Jitters or Doesn't Move

**Symptoms:**
- Servo vibrates but doesn't rotate
- Weak servo movement
- Servo gets hot

**Causes:**
- Insufficient current from power supply
- Voltage drop due to long wires
- Servo stall (blocked)

**Solutions:**
1. ✅ Use 3A power supply minimum
2. ✅ Shorten power wires
3. ✅ Check servo isn't mechanically blocked
4. ✅ Test servo with fresh batteries

### Issue 3: Pump Doesn't Run

**Symptoms:**
- Relay clicks but pump doesn't run
- Relay doesn't click at all

**Causes:**
- Relay wired incorrectly
- Pump requires more voltage/current
- Control signal inverted

**Solutions:**
1. ✅ Check relay wiring (COM, NO, NC)
2. ✅ Verify Pin 11 goes LOW when activated
3. ✅ Test pump directly with power supply
4. ✅ Check relay indicator LED

### Issue 4: Raspberry Pi Undervoltage Warning

**Symptoms:**
- Lightning bolt icon on screen
- RPi slows down or crashes
- USB devices disconnect

**Causes:**
- Weak power supply
- Arduino drawing too much from USB
- Bad USB cable

**Solutions:**
1. ✅ Use official 5V 3A RPi power supply
2. ✅ Power Arduino separately
3. ✅ Use shorter, thicker USB cables
4. ✅ Check power adapter with multimeter

---

## 💡 Pro Tips

### Tip 1: Power Supply Selection

- **Buy quality:** Cheap power supplies cause 90% of problems
- **Overhead:** Use 3A supply even if motors only need 1.5A
- **Regulated:** Ensure power supply is regulated (stable voltage)
- **Check polarity:** Center-positive for Arduino (standard)

### Tip 2: Wire Management

- **Thick wires for power:** Use 20-22 AWG for VCC/GND
- **Thin wires for signals:** Use 24-26 AWG for control
- **Keep short:** Minimize wire length for motors
- **Color code:** Red=VCC, Black=GND, other colors=signals

### Tip 3: Capacitors (Optional but Recommended)

Add capacitors to smooth power:
- **100µF electrolytic** across Arduino VCC/GND
- **470µF electrolytic** across motor power supply
- **0.1µF ceramic** near each IC

### Tip 4: Fuses (Safety)

Add fuses for protection:
- **2A fuse** in motor power supply line
- **500mA fuse** in Arduino power line
- Use blade fuses with holders

---

## 📐 Power Budget Calculation

```
COMPONENT POWER CONSUMPTION:

Raspberry Pi 4:
├─ Idle: 600mA @ 5V = 3W
└─ Active: 1200mA @ 5V = 6W

Arduino Uno:
├─ Logic: 50mA @ 5V = 0.25W
└─ With sensors: 150mA @ 5V = 0.75W

Servo Motor (SG90):
├─ Idle: 10mA @ 5V = 0.05W
├─ Moving: 300-500mA @ 5V = 1.5-2.5W
└─ Stall: 1000mA @ 5V = 5W

Water Pump:
├─ Running: 200mA @ 5V = 1W
└─ Peak: 400mA @ 5V = 2W

Relay Module:
└─ Active: 70mA @ 5V = 0.35W

LCD Display:
└─ With backlight: 40mA @ 5V = 0.2W

RTC Module:
└─ Always on: 5mA @ 5V = 0.025W

TOTAL PEAK POWER:
RPi (1200mA) + Arduino (150mA) + Servo (500mA) + Pump (400mA) 
+ Relay (70mA) + LCD (40mA) + RTC (5mA) = 2365mA

RECOMMENDED POWER SUPPLIES:
├─ RPi: 5V 3A (15W) → Powers RPi only
├─ Motors: 5V 3A (15W) → Powers servo + pump + relay
└─ Arduino: USB from RPi or separate 9V 1A
```

---

## ✅ Final Checklist

Before powering on the complete system:

- [ ] Raspberry Pi has dedicated 5V 3A power supply
- [ ] Motors (servo + pump) have separate 5V 2-3A supply
- [ ] All grounds connected together (common ground)
- [ ] Servo VCC/GND to motor power supply (NOT Arduino)
- [ ] Pump through relay, relay powered by motor supply
- [ ] Servo signal wire to Arduino Pin 10
- [ ] Relay control wire to Arduino Pin 11
- [ ] USB cable connects RPi to Arduino (communication)
- [ ] No motors connected to Arduino 5V pin
- [ ] All connections secure and insulated
- [ ] No short circuits (check with multimeter)
- [ ] Power supplies correct polarity
- [ ] Fuses installed (if using)

---

## 🎯 Summary - Power Architecture

**The Golden Rule:** Motors get their own power supply!

```
✅ CORRECT:
RPi (own power) → Arduino (USB or own power) → Control signals only
Motor Power Supply (dedicated) → Servo + Pump

❌ WRONG:
RPi → Arduino → Arduino 5V pin → Servo + Pump (WILL CRASH!)
```

**Why This Matters:**
- Prevents board damage
- Eliminates brownouts and resets
- Ensures stable 24/7 operation
- Protects your expensive Raspberry Pi

**Cost:**
- Total power supplies needed: $15-25
- Cheap insurance for $100+ worth of electronics!

---

**Questions? Check the troubleshooting section or test step-by-step!**


---

## 🔋 SPECIAL: Using 3-Cell Battery Holder (4.5V)

### Your Question: Can I use 3x 1.5V batteries?

**Short Answer:**
- ✅ **YES for water pump alone** - Works perfectly!
- ❌ **NO for both servo + pump** - Not enough power
- ⚠️ **Maybe for servo from RPi** - Risky but possible

---

### Configuration 1: Battery for Pump Only (RECOMMENDED)

```
┌─────────────────────────────────────────────────┐
│     USING YOUR 3-CELL BATTERY HOLDER            │
└─────────────────────────────────────────────────┘

3x AA Batteries (4.5V)
    │
    ├─→ Battery (+) ──→ Relay COM
    │                   │
    └─→ Battery (-) ──→ Relay GND ──→ Arduino GND
                        │
                        └──→ Pump (-)

Relay Connections:
├─ VCC → Arduino 5V pin (relay needs 5V)
├─ GND → Battery (-) and Arduino GND
├─ IN  → Arduino Pin 11
├─ COM → Battery (+) 4.5V
└─ NO  → Pump (+)

Servo Motor:
├─ Get separate power source (see below)
└─ OR use Arduino 5V pin (testing only!)

Why this works:
✅ 4.5V perfect for water pump (3-6V range)
✅ AA batteries provide enough current (2000mAh)
✅ Pump draws 100-300mA (battery lasts months)
✅ Isolated from main system (safe)
✅ Portable (no wall outlet needed)

Battery Life:
- Pump runtime: 5 seconds per dispense
- Pump current: 250mA average
- Dispenses per day: 5 times
- Total daily: 5 × 5 sec = 25 seconds = 0.007 hours
- Battery capacity: 2000mAh
- Estimated life: 2000mAh / (250mA × 0.007h/day) 
                = 1100+ days per battery set!
```

---

### Configuration 2: Split Power (TESTING PHASE)

```
┌─────────────────────────────────────────────────┐
│   TEMPORARY SETUP FOR TESTING                   │
│   (Use only if you can't get more batteries)    │
└─────────────────────────────────────────────────┘

Servo Motor (TESTING ONLY):
└─→ Arduino 5V pin (⚠️ may cause resets)
    ├─ Red wire → Arduino 5V
    ├─ Brown → Arduino GND
    └─ Orange → Arduino Pin 10

Water Pump (PERFECT):
└─→ 3x Battery Holder (4.5V)
    └─→ Through relay as shown above

⚠️  WARNING for Servo on Arduino 5V:
├─ Arduino 5V pin max: ~400mA
├─ Servo moving: 200-500mA (borderline)
├─ Servo stall: 1000mA (will crash!)
└─ Works ONLY if:
    ✓ Servo doesn't get blocked
    ✓ Food dispenser is very light
    ✓ Servo runs briefly (< 3 seconds)
    ✓ You accept occasional Arduino resets

Signs of trouble:
❌ Arduino resets when servo moves
❌ LCD blanks out
❌ Power LED dims
❌ Servo jitters or doesn't move
→ If any of these happen: Servo needs external power!
```

---

### Configuration 3: Add One More Battery (BEST!)

```
┌─────────────────────────────────────────────────┐
│   RECOMMENDED UPGRADE: 4-CELL HOLDER            │
│   Cost: $2-5 for 4x AA battery holder           │
└─────────────────────────────────────────────────┘

4x AA Batteries (6V)
    │
    ├─→ (+) 6V Rail
    │   ├──→ Servo VCC (Red wire)
    │   └──→ Relay COM → Pump (+)
    │
    └─→ (-) GND Rail
        ├──→ Servo GND (Brown wire)
        ├──→ Relay GND
        ├──→ Pump (-)
        └──→ Arduino GND ⚠️ CRITICAL!

Control Signals:
├─ Servo signal (Orange) → Arduino Pin 10
└─ Relay IN → Arduino Pin 11

Why 6V is better than 4.5V:
✅ Servo rated voltage: 4.8-6V (6V is nominal)
✅ More torque: 1.8kg-cm @ 4.8V → 2.5kg-cm @ 6V
✅ Reliable operation even as batteries drain
✅ 6V → 5V as batteries age (still good)
✅ Both motors powered from one pack

Battery Life (with 4-cell):
- Same calculation as 3-cell
- Slightly higher voltage = same current
- ~1000+ days with typical use
```

---

### Configuration 4: Two Battery Packs (SAFEST)

```
┌─────────────────────────────────────────────────┐
│   IF YOU WANT TO USE YOUR 3-CELL HOLDER         │
│   AND have reliable servo operation              │
└─────────────────────────────────────────────────┘

Battery Pack 1: 4x AA (6V)
    └─→ Servo motor only
        ├─ Red → Battery (+) 6V
        ├─ Brown → Battery (-)
        ├─ Orange → Arduino Pin 10
        └─ GND connected to Arduino GND

Battery Pack 2: 3x AA (4.5V) - YOUR EXISTING ONE
    └─→ Water pump via relay
        └─→ Wired as shown in Config 1

Common Ground:
⚠️  All grounds connected:
    Battery 1 (-) ↔ Battery 2 (-) ↔ Arduino GND

Why use two packs:
✅ Each motor optimized for its voltage
✅ No interaction between motors
✅ Servo gets 6V (better performance)
✅ Pump gets 4.5V (perfectly adequate)
✅ Independent operation
✅ Easy troubleshooting

Total cost: $2-3 for one more 4-cell holder
```

---

### What to Buy (Recommendations)

#### Option 1: Upgrade to 4-Cell (Simplest)
```
Item: 4x AA Battery Holder with switch
Price: $2-5
Batteries: 4x AA (any brand)
Result: Powers both servo + pump perfectly

Where to buy:
- Amazon: "4xAA battery holder with leads"
- Local electronics store
- Hardware store
```

#### Option 2: Keep 3-Cell, Add 5V Adapter for Servo
```
Item: 5V 2A DC Power Adapter
Price: $6-12
Connection: Wall → Breadboard → Servo
Battery: Your 3-cell for pump
Result: Servo unlimited power, pump portable

Best for: Permanent installation near outlet
```

#### Option 3: Second Battery Pack
```
Item: 4x AA Battery Holder
Price: $2-5
Use: Servo only (6V)
Keep: Your 3-cell for pump (4.5V)
Result: Fully portable, both motors happy
```

---

### Testing Your Current Setup

**Before buying anything, test this:**

```bash
# Test 1: Water Pump on 3-Cell Battery
1. Wire pump through relay to your 3x battery holder
2. Connect relay control to Arduino Pin 11
3. Connect battery (-) to Arduino GND ⚠️ CRITICAL
4. Upload test code:

void setup() {
  pinMode(11, OUTPUT);
  digitalWrite(11, HIGH); // Relay off (active LOW)
}

void loop() {
  digitalWrite(11, LOW);   // Turn pump ON
  delay(5000);             // Run 5 seconds
  digitalWrite(11, HIGH);  // Turn pump OFF
  delay(10000);            // Wait 10 seconds
}

Expected: Pump runs smoothly for 5 seconds
If works: ✅ Your battery holder is perfect for pump!
```

```bash
# Test 2: Servo on Arduino 5V (Careful!)
1. Wire servo to Arduino:
   - Red → Arduino 5V
   - Brown → Arduino GND
   - Orange → Pin 10
   
2. Upload test code:

#include <Servo.h>
Servo servo;

void setup() {
  servo.attach(10);
  Serial.begin(115200);
}

void loop() {
  Serial.println("Moving servo...");
  servo.write(0);
  delay(1000);
  servo.write(90);
  delay(1000);
  Serial.println("Done");
}

Expected: Servo moves without Arduino resetting
If Arduino resets: ❌ Servo needs external power
If works smoothly: ✅ Might work for your project
```

---

### Decision Tree

```
Do you have a 3-cell battery holder (4.5V)?
    │
    ├─ YES → Use it for water pump ✅
    │         │
    │         └─ For servo motor:
    │             │
    │             ├─ Test on Arduino 5V first
    │             │  │
    │             │  ├─ Works? → Use it (accept minor risk)
    │             │  └─ Resets? → Need external power
    │             │
    │             ├─ Buy 4-cell holder ($3) → Best solution
    │             ├─ Buy 5V adapter ($8) → Most reliable
    │             └─ Buy second holder ($3) → Fully portable
    │
    └─ NO → Buy 4-cell holder for both motors
            OR buy 5V adapter for both
            
Budget decision:
├─ $0: Test servo on Arduino 5V (may work)
├─ $3: Buy 4-cell battery holder (recommended!)
└─ $8: Buy 5V wall adapter (most reliable)
```

---

### ⚡ Quick Answer for You

**Based on what you have:**

1. **Use your 3-cell battery holder (4.5V) for water pump** ✅
   - This is perfect and will work great!
   - Battery will last months

2. **For servo motor - 3 choices:**
   
   **A. Test on Arduino 5V pin** (FREE - try first)
   - Might work if servo load is light
   - Risk: Arduino may reset occasionally
   - Good for testing/prototyping
   
   **B. Buy 4-cell battery holder** ($2-5 - best upgrade)
   - 6V powers both servo + pump perfectly
   - Fully portable
   - No risks to boards
   - Recommended solution!
   
   **C. Use 5V wall adapter for servo** ($6-12 - most reliable)
   - Keep battery for pump (portable)
   - Servo unlimited power
   - Best for permanent setup

**My recommendation: Try option A first (free), then upgrade to B if needed ($3).**

---

## 🎯 Summary

Your 3x battery holder (4.5V) is **perfect for the water pump**!

For servo:
- **Short term:** Test on Arduino 5V (might work)
- **Long term:** Get 4-cell holder or wall adapter

**Total additional cost: $0-$8 depending on your choice**

Good luck! 🔋⚡
