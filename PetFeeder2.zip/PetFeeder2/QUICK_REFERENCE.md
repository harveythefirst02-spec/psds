# Pet Feeder System - Quick Reference Card

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Initialize database
node database/init.js

# 3. Upload Arduino code
# Open pet_feeder.ino in Arduino IDE → Upload

# 4. Start server
npm start

# 5. Access system
http://localhost:3000
```

## 🔑 Default Login

- **Admin**: `admin` / `admin123`
- **Create users**: Via admin dashboard

## 📡 Arduino Commands

| Send to Arduino | Arduino Responds |
|----------------|------------------|
| `DISPENSE_FOOD` | `FOOD_DONE` |
| `DISPENSE_WATER` | `WATER_DONE` |
| `DISPENSE_BOTH` | `BOTH_DONE` |
| `GET_STATUS` | `STATUS_ONLINE` |

## 🔌 Serial Connection

| Platform | Typical Port |
|----------|-------------|
| Raspberry Pi | `/dev/ttyUSB0` or `/dev/ttyACM0` |
| Windows | `COM3`, `COM4`, etc. |
| Mac | `/dev/cu.usbmodem` |

**Baud Rate:** 115200

## 📂 Key Files

```
Backend Communication:
├── serial/arduinoSerial.js  ← Core bridge
├── routes/api.js            ← HTTP endpoints
└── server.js                ← Initialization

Frontend Controls:
├── user/user.js             ← Feed buttons
├── admin/admin.js           ← Device monitoring
└── pet_feeder.ino           ← Arduino code
```

## 🔧 Common Issues

### Arduino Not Found
```bash
# Linux/RPi
sudo chmod 666 /dev/ttyUSB0
sudo usermod -a -G dialout $USER

# Restart server
npm start
```

### Test Communication
```bash
node test_arduino_communication.js
```

### Database Reset
```bash
rm database/petfeeder.db
node database/init.js
```

## 🌐 Endpoints

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/dispense/food` | POST | Dispense food |
| `/api/dispense/water` | POST | Dispense water |
| `/api/dispense/both` | POST | Dispense both |
| `/api/arduino/status` | GET | Check connection |

## 🔔 Socket.IO Events

| Event | Direction | Data |
|-------|-----------|------|
| `arduino-status` | Server → Client | `{ status, port }` |
| `dispense-complete` | Server → Client | `{ type, status, timestamp }` |
| `arduino-response` | Server → Client | `{ response, timestamp }` |
| `arduino-error` | Server → Client | `{ error }` |

## 📊 Database Tables

```sql
users            -- User accounts & pet info
schedules        -- Feeding schedules
feeding_logs     -- All feeding history
commands         -- Arduino commands sent
device_status    -- Arduino connection status
system_logs      -- All system events
```

## 🎨 User Dashboard Sections

1. **Home** - Pet info, last feeding, device status
2. **Feed Control** - Manual dispense (Food/Water/Both)
3. **Schedules** - Create/edit feeding times
4. **History** - View logs, export CSV
5. **Profile** - Update pet details
6. **Settings** - Password, theme, preferences

## 👨‍💼 Admin Dashboard Sections

1. **Overview** - Statistics & real-time metrics
2. **Users** - CRUD operations on users
3. **Logs** - System & feeding logs
4. **Device** - Arduino monitoring
5. **Settings** - System configuration

## 🔒 Security

- ✅ Bcrypt password hashing
- ✅ Session-based authentication
- ✅ Role-based access (admin/user)
- ✅ Input validation
- ✅ SQL injection prevention

## 📦 NPM Scripts

```bash
npm start        # Start production server
npm run dev      # Development with nodemon
npm run init-db  # Initialize database
```

## 🐛 Debugging

### View Arduino Messages
```bash
# Arduino IDE → Tools → Serial Monitor (115200 baud)
```

### View Server Logs
```bash
# Terminal running npm start
# Shows all Arduino communication
```

### View Browser Logs
```javascript
// Browser console (F12)
// Shows Socket.IO events
```

## 📞 Quick Commands Test

```javascript
// In Arduino Serial Monitor (115200 baud):
GET_STATUS
DISPENSE_FOOD
DISPENSE_WATER
DISPENSE_BOTH
```

## 🔄 Data Flow

```
User clicks "Feed" button
  ↓
user.js → fetch('/api/dispense/food')
  ↓
routes/api.js → arduinoSerial.sendCommand()
  ↓
serial/arduinoSerial.js → USB Serial
  ↓
Arduino → Execute → Respond "FOOD_DONE"
  ↓
arduinoSerial.js → Database log
  ↓
Socket.IO broadcast → All clients updated
```

## ⚡ Performance

- WebSocket for real-time updates
- SQLite with indexes
- Auto-reconnect on Arduino disconnect
- 10-second cooldown between manual feeds
- Session timeout: 24 hours

---

**Need more help?** See:
- `ARDUINO_INTEGRATION_GUIDE.md` - Detailed setup
- `PROJECT_README.md` - Complete documentation
- `FILE_STRUCTURE_DETAILED.md` - All files explained
