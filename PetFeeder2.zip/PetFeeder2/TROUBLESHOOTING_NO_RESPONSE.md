# Troubleshooting: Arduino Not Responding

## Your Current Situation

✅ **Test ran successfully** - Commands are being sent  
❌ **No responses received** - Arduino not sending data back  
❌ **No servo movement** - Physical hardware not activating  
❌ **No LCD updates** - Display not showing feed actions  

---

## Root Cause

The Arduino is still running **OLD CODE with 9600 baud**. The fix I made only updated the `.ino` file on your computer, but the Arduino chip still has the old program in its memory.

### Think of it like this:
- 📄 **Computer file** (.ino) = ✅ Fixed (115200 baud)
- 🔧 **Arduino chip** = ❌ Still running old code (9600 baud)

The Arduino won't use the new code until you **upload** it!

---

## Solution: Upload the Fixed Code

### Step 1: Close Any Programs Using the Arduino Port

Before uploading, you must close:
- ❌ Close your Node.js server (`Ctrl+C` in terminal if running)
- ❌ Close any Arduino Serial Monitor windows
- ❌ Close the test script if still running

**Why?** Only ONE program can talk to the Arduino at a time. If your server is connected, the Arduino IDE cannot upload.

### Step 2: Open Arduino IDE

1. Launch **Arduino IDE** (version 1.8.x or 2.x)
2. Open your file: **File → Open** → Navigate to:
   ```
   C:\Users\jhea\OneDrive\Desktop\Techno\PetFeeder2\pet_feeder.ino
   ```

### Step 3: Verify Settings

1. **Board Selection:**
   - Go to: **Tools → Board → Arduino AVR Boards → Arduino Uno**
   
2. **Port Selection:**
   - Go to: **Tools → Port**
   - Select: **COM3** (Arduino Uno) — or whichever port shows your Arduino
   - If you don't see any ports, your Arduino isn't detected:
     - Try a different USB cable
     - Try a different USB port on your computer
     - Check if Arduino has power (LED should be on)

### Step 4: Upload the Code

1. Click the **Upload** button (→ arrow icon) in the toolbar
2. Watch the progress bar at the bottom
3. Wait for **"Done uploading"** message (should take 5-10 seconds)

**What you'll see during upload:**
```
Compiling sketch...
Sketch uses 15234 bytes (47%) of program storage space
Global variables use 892 bytes (43%) of dynamic memory
Uploading...
Writing | ################################################## | 100%
Done uploading.
```

### Step 5: Open Serial Monitor to Verify

After upload completes:

1. Click **Tools → Serial Monitor** (or `Ctrl+Shift+M`)
2. **IMPORTANT:** Set baud rate to **115200** in the dropdown (bottom-right)
3. The Arduino will reset and you should immediately see:

```
Pet Feeder Starting...
RTC lost power, setting default time
READY
Pet Feeder System Online
A=Add B=View C=Delete D=Clear
```

**If you see gibberish** (like `œ�ø∑ßç`):
- ❌ The baud rate is wrong
- Change the Serial Monitor dropdown to **115200**

**If you see nothing:**
- Press the **RESET button** on the Arduino
- Wait 3 seconds for startup messages

### Step 6: Test Commands in Serial Monitor

In the Serial Monitor input box (top), type these commands and press Enter:

| Command | Expected Response |
|---------|------------------|
| `GET_STATUS` | `STATUS_ONLINE`<br>`SCHEDULES:0`<br>`UPTIME:XX` |
| `DISPENSE_FOOD` | `[Arduino] Received command: DISPENSE_FOOD`<br>`[Arduino] Executing DISPENSE_FOOD`<br>`Dispensing food...`<br>`FOOD_DONE` |

**What should physically happen:**
- ✅ Servo should rotate to 180°, wait 3 seconds, return to 0°
- ✅ LCD should show "DISPENSING FOOD..."
- ✅ After 3 seconds, LCD shows "FOOD DISPENSED!"

### Step 7: Close Serial Monitor & Run Test Again

1. **Close the Serial Monitor window** (very important!)
2. Go back to your project terminal
3. Run the test:
   ```bash
   node test_arduino_communication.js
   ```

**Expected NEW output:**
```
← Arduino: Pet Feeder Starting...
← Arduino: READY
← Arduino: Pet Feeder System Online

Test 1: Status Check
→ Sending: GET_STATUS
← Arduino: STATUS_ONLINE
← Arduino: SCHEDULES:0
← Arduino: UPTIME:15

Test 2: Food Dispense
→ Sending: DISPENSE_FOOD
← Arduino: [Arduino] Received command: DISPENSE_FOOD
← Arduino: [Arduino] Executing DISPENSE_FOOD
← Arduino: Dispensing food...
← Arduino: FOOD_DONE

✓ Servo physically moves
✓ LCD updates in real-time
```

---

## If Still No Response After Upload

### Check 1: Verify Baud Rate Was Really Changed

Open `pet_feeder.ino` and check line 83:
```cpp
void setup() {
  Serial.begin(115200);  // ← Should be 115200, NOT 9600
```

If it still says `9600`, the file didn't save. Fix it and upload again.

### Check 2: Check for Compilation Errors

When you click Upload, check the black console area at the bottom. If you see red error messages:
- **Missing libraries?** Install them via **Tools → Manage Libraries**
- **Syntax errors?** Read the error message carefully

### Check 3: Verify Port Isn't Changing

Some USB-to-Serial adapters change port numbers on reset. 

Check your port again:
- **Tools → Port** — is it still COM3?
- If it changed to COM4, update `arduinoSerial.js`:
  ```javascript
  this.portPath = 'COM4'; // Update to match
  ```

### Check 4: Check for Hardware Issues

**Servo not moving?**
- Check wiring:
  - Signal wire → Pin 10
  - Red wire → 5V
  - Brown/Black wire → GND
- Try a different servo
- Test with Arduino IDE examples: **File → Examples → Servo → Sweep**

**LCD not updating?**
- Check I2C connections:
  - SDA → A4
  - SCL → A5
  - VCC → 5V
  - GND → GND
- Run I2C scanner to find correct address

---

## Quick Diagnostic Checklist

Before asking for more help, verify:

- [ ] I have uploaded the new code to Arduino
- [ ] Serial Monitor at 115200 baud shows startup messages
- [ ] Serial Monitor commands work (`GET_STATUS` → response)
- [ ] Servo is properly wired to Pin 10
- [ ] LCD is properly wired to I2C (A4, A5)
- [ ] All programs using COM3 are closed before testing
- [ ] Arduino has external power if using pump (5V from USB might not be enough)

---

## Expected Test Results After Fix

### Before Upload (Current State)
```
Test 1: Status Check
→ Sending: GET_STATUS
(no response - timeout)

Test 2: Food Dispense
→ Sending: DISPENSE_FOOD
(no response - timeout)
```

### After Upload (Fixed)
```
← Arduino: READY

Test 1: Status Check
→ Sending: GET_STATUS
← Arduino: STATUS_ONLINE
← Arduino: SCHEDULES:0

Test 2: Food Dispense
→ Sending: DISPENSE_FOOD
← Arduino: FOOD_DONE
(servo physically moves, LCD updates)
```

---

## Summary

**YOU MUST:**
1. Close all programs using COM3
2. Open Arduino IDE
3. Open `pet_feeder.ino`
4. Select Board: Arduino Uno
5. Select Port: COM3
6. Click Upload (→)
7. Wait for "Done uploading"
8. Test in Serial Monitor at 115200 baud
9. Close Serial Monitor
10. Run `node test_arduino_communication.js` again

The code fix is done. Now you just need to upload it to the Arduino chip!
