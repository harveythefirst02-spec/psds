# Servo Motor Troubleshooting

## Current Status
✅ **Arduino communication working** - Commands received and executed  
✅ **LCD display working** - Shows "DISPENSING FOOD..."  
❌ **Servo not moving** - No physical movement detected  

---

## Why Servo Isn't Moving

### Possibility 1: Servo Not Connected or Wrong Wiring ⚠️

**Check your servo wiring:**

```
Servo Motor Pins:
┌─────────────────┐
│ Brown/Black     │ → Arduino GND
│ Red             │ → Arduino 5V (or external 5V)
│ Orange/Yellow   │ → Arduino Pin 10
└─────────────────┘
```

**Common wiring mistakes:**
- ❌ Signal wire on wrong pin (should be Pin 10)
- ❌ Power wires reversed (red to GND, black to 5V)
- ❌ Loose connections in breadboard
- ❌ Servo power wire not connected at all

**How to verify:**
1. Check each wire is firmly inserted
2. Verify colors match the diagram above
3. Confirm signal wire goes to Pin 10 specifically

---

### Possibility 2: Insufficient Power 🔋

**Servo motors need MORE power than Arduino can provide through USB!**

**Current setup:**
- Arduino powered by USB (500mA max)
- Servo can draw 100-500mA when moving
- LCD, RTC, Keypad also drawing power
- **Total power may exceed USB capacity**

**Symptoms of power issue:**
- LCD works (low power)
- Servo doesn't move (high power)
- Arduino resets when servo tries to move
- Brown-out or flickering

**Solutions:**

#### Option A: External 5V Power Supply (RECOMMENDED)
```
External 5V Power Supply (1-2A)
         │
         ├─→ Servo RED wire
         └─→ Arduino VIN pin

Common GND:
Arduino GND ←─→ Power Supply GND ←─→ Servo BROWN/BLACK wire
```

#### Option B: Separate Servo Power
```
External 5V Power (for servo only)
         ├─→ Servo RED wire
         └─→ Servo BROWN/BLACK wire (GND)
         
Connect GND together:
Arduino GND ←─→ Servo GND (share common ground!)

Servo SIGNAL → Arduino Pin 10
```

**What to buy:**
- 5V 2A power adapter (wall plug)
- Or 5V power bank
- Or 4x AA batteries (6V - works with servos)

---

### Possibility 3: Faulty Servo 🔧

**Test if servo is broken:**

#### Test 1: Arduino Example Code
1. Open Arduino IDE
2. **File → Examples → Servo → Sweep**
3. Change line `myservo.attach(9);` to `myservo.attach(10);`
4. Upload and watch

**If servo moves with example code:**
- ✅ Servo is working
- ✅ Wiring is correct
- ❌ Problem is in our code (unlikely)

**If servo still doesn't move:**
- Try a different servo motor
- Test the suspected broken servo on a different Arduino pin

---

### Possibility 4: Servo Library Conflict

Some Arduino boards or library versions have conflicts. Try this alternative servo library:

```cpp
// At the top of the file, replace:
#include <Servo.h>

// With:
#include <ServoTimer2.h>  // Alternative library
```

---

## Diagnostic Commands

I've added debug commands to help diagnose. Upload the updated code and try these:

### Command 1: `TEST_SERVO`

In Serial Monitor, type:
```
TEST_SERVO
```

**This will:**
- Move servo slowly through positions: 0° → 45° → 90° → 135° → 180° → 0°
- Take 6 seconds total
- Print debug messages for each position

**Expected output:**
```
Testing servo...
Moving to 0
Moving to 45
Moving to 90
Moving to 135
Moving to 180
Moving back to 0
SERVO_TEST_DONE
```

**Watch your servo during this test!**
- ✅ **If it moves:** Servo and wiring are fine, power might be insufficient for 180° jump
- ❌ **If it doesn't move at all:** Check wiring or power supply

---

### Command 2: `DISPENSE_FOOD` (Enhanced Debug)

Now includes detailed debug output:
```
[DEBUG] Moving servo to 180 degrees
(3 second pause - servo should be at 180°)
[DEBUG] Returning servo to 0 degrees
[DEBUG] Servo movement complete
FOOD_DONE
```

---

## Step-by-Step Diagnostic Process

### Step 1: Upload Updated Code
```bash
# In Arduino IDE, click Upload (→)
```

### Step 2: Open Serial Monitor
- Set to 115200 baud
- Press Arduino RESET button
- Verify you see "READY" message

### Step 3: Run Servo Test
```
TEST_SERVO
```

**Observe:**
- Does servo make ANY sound? (humming/buzzing means it's trying but can't)
- Does servo get warm? (means it's receiving power)
- Does servo physically rotate?

### Step 4: Check Results

| Symptom | Diagnosis | Fix |
|---------|-----------|-----|
| No sound, no movement, servo cold | Not connected or wrong pin | Check wiring, confirm Pin 10 |
| Humming/buzzing but no movement | Insufficient power OR broken servo | Add external power supply |
| Jitters slightly but doesn't rotate | Barely enough power | External 5V power required |
| Moves with TEST_SERVO but not DISPENSE_FOOD | Code issue (unlikely) | Report back |
| No movement at all | Broken servo | Replace servo |

---

## Quick Wiring Verification Checklist

- [ ] Servo signal wire connected to Arduino **Pin 10** (not 9, 11, or other)
- [ ] Servo red wire connected to **5V**
- [ ] Servo brown/black wire connected to **GND**
- [ ] All connections are **firm** (not loose)
- [ ] Servo is **SG90 or similar** (standard 180° servo)
- [ ] External power supply connected (if using high-power servo)
- [ ] **Common ground** connected if using separate power supply

---

## Testing Without Arduino Code

Want to verify servo works independently? Try this minimal test code:

```cpp
#include <Servo.h>

Servo testServo;

void setup() {
  Serial.begin(115200);
  Serial.println("Servo Test Starting...");
  
  testServo.attach(10);
  testServo.write(0);
  Serial.println("Servo initialized at 0 degrees");
}

void loop() {
  Serial.println("Moving to 180");
  testServo.write(180);
  delay(2000);
  
  Serial.println("Moving to 0");
  testServo.write(0);
  delay(2000);
}
```

Upload this and the servo should sweep back and forth every 2 seconds.

---

## Common Servo Models & Current Draw

| Servo Model | Operating Voltage | Current Draw | USB Safe? |
|-------------|------------------|--------------|-----------|
| SG90 (micro) | 4.8-6V | 100-250mA | Borderline ⚠️ |
| MG90S | 4.8-6V | 150-350mA | No ❌ |
| TowerPro SG90 | 4.8-6V | 100-220mA | Borderline ⚠️ |
| Futaba S3003 | 4.8-6V | 300-700mA | No ❌ |

**USB provides 500mA total.** Your Arduino + LCD + RTC + Keypad already use ~150mA, leaving only ~350mA for servo.

**Recommendation:** Always use external power for reliable servo operation.

---

## Next Steps

1. **Upload the updated code** with TEST_SERVO command
2. **Run `TEST_SERVO`** in Serial Monitor
3. **Report back:**
   - Did servo make any sound?
   - Did it move at all?
   - Any movement/jittering/humming?
4. **Check wiring** against the diagram above
5. **Consider adding external power** if servo seems underpowered

Once we confirm the servo hardware is working, we can proceed to test from the web interface!
