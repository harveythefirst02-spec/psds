# Exact Code Changes Needed on Raspberry Pi

## Important Note
These changes were made on the **Windows machine** but need to be applied on the **Raspberry Pi** where the server runs.

---

## File 1: `user/user.js`

**Location:** `/home/pi/PetFeeder2/user/user.js`

**Find this code (around line 120):**
```javascript
  socket.on('schedule-deleted', () => {
    if (currentSection === 'schedule') {
      loadSchedules();
    }
    loadDashboard();
  });
}
```

**Replace with:**
```javascript
  socket.on('schedule-deleted', () => {
    if (currentSection === 'schedule') {
      loadSchedules();
    }
    loadDashboard();
  });
  
  // Listen for feeding logs (real-time history update)
  socket.on('feeding-logged', (data) => {
    console.log('[Feeding Logged]:', data);
    
    // Refresh dashboard to show latest feeding
    if (currentSection === 'home') {
      loadDashboard();
    }
    
    // Refresh history if on history page
    if (currentSection === 'history') {
      loadHistory();
    }
  });
}
```

---

## File 2: `routes/user.js`

**Location:** `/home/pi/PetFeeder2/routes/user.js`

**Find this code (around line 100):**
```javascript
  const db = req.app.locals.db;
  
  db.run(
    `INSERT INTO schedules (user_id, hour, minute, ampm, dispense_type, is_active) 
     VALUES (?, ?, ?, ?, ?, 1)`,
    [userId, hour, minute, ampm, dispense_type],
    function(err) {
      if (err) {
        console.error('Error creating schedule:', err);
        return res.json({ success: false, message: 'Error creating schedule' });
      }

      // Log action
      db.run(
        `INSERT INTO system_logs (log_type, message) VALUES ('schedule_created', ?)`,
        [`User ${userId} created schedule: ${hour}:${minute} ${ampm}`]
      );

      // Broadcast update
      req.app.locals.io.emit('schedule-created', {
```

**Replace with:**
```javascript
  const db = req.app.locals.db;
  const arduinoSerial = require('../serial/arduinoSerial');
  
  db.run(
    `INSERT INTO schedules (user_id, hour, minute, ampm, dispense_type, is_active) 
     VALUES (?, ?, ?, ?, ?, 1)`,
    [userId, hour, minute, ampm, dispense_type],
    function(err) {
      if (err) {
        console.error('Error creating schedule:', err);
        return res.json({ success: false, message: 'Error creating schedule' });
      }

      // Log action
      db.run(
        `INSERT INTO system_logs (log_type, message) VALUES ('schedule_created', ?)`,
        [`User ${userId} created schedule: ${hour}:${minute} ${ampm}`]
      );

      // Sync to Arduino
      if (arduinoSerial.isConnected()) {
        arduinoSerial.sendScheduleToArduino(hour, minute, ampm, dispense_type)
          .then(() => {
            console.log(`✓ Schedule synced to Arduino: ${hour}:${minute} ${ampm}`);
          })
          .catch(err => {
            console.error('Failed to sync schedule to Arduino:', err.message);
          });
      } else {
        console.warn('Arduino not connected - schedule not synced');
      }

      // Broadcast update
      req.app.locals.io.emit('schedule-created', {
```

---

## File 3: `serial/arduinoSerial.js`

**Location:** `/home/pi/PetFeeder2/serial/arduinoSerial.js`

### Change 3A: Update handleDispenseComplete function

**Find this code (around line 220):**
```javascript
  handleDispenseComplete(type, status) {
    const userId = this.currentCommand ? this.currentCommand.userId : null;
    
    // Log to database
    if (this.db && type) {
      this.db.run(
        `INSERT INTO feeding_logs (user_id, dispense_type, source, status) VALUES (?, ?, 'manual', ?)`,
        [userId, type, status],
        (err) => {
          if (err) console.error('Error logging dispense:', err);
        }
      );
    }

    // Broadcast to all clients
    if (this.io) {
      this.io.emit('dispense-complete', { 
        type, 
        status, 
        timestamp: new Date() 
      });
    }
```

**Replace with:**
```javascript
  handleDispenseComplete(type, status) {
    const userId = this.currentCommand ? this.currentCommand.userId : null;
    const source = this.currentCommand ? 'manual' : 'scheduled';
    
    // Log to database
    if (this.db && type) {
      this.db.run(
        `INSERT INTO feeding_logs (user_id, dispense_type, source, status) VALUES (?, ?, ?, ?)`,
        [userId, type, source, status],
        (err) => {
          if (err) {
            console.error('Error logging dispense:', err);
          } else {
            console.log(`✓ Feeding logged: ${type} (${source}) - ${status}`);
            
            // Broadcast new feeding log to all clients
            if (this.io) {
              this.io.emit('feeding-logged', { 
                userId, 
                type, 
                source, 
                status, 
                timestamp: new Date() 
              });
            }
          }
        }
      );
    }

    // Broadcast dispense completion
    if (this.io) {
      this.io.emit('dispense-complete', { 
        type, 
        status, 
        timestamp: new Date() 
      });
    }
```

### Change 3B: Update handleArduinoResponse function

**Find this code (around line 200):**
```javascript
    else if (response.includes('SCHEDULE_ADDED')) {
      console.log('[Arduino] Schedule added successfully');
      if (this.io) {
        this.io.emit('arduino-schedule-added', { success: true });
      }
    }
```

**Replace with:**
```javascript
    else if (response.includes('SCHEDULE_ADDED')) {
      console.log('[Arduino] Schedule added successfully');
      
      // Check if this is a schedule notification from keypad
      if (response.includes(':')) {
        // Format: SCHEDULE_ADDED:8,30,AM,food
        const parts = response.split(':');
        if (parts.length === 2) {
          const params = parts[1].split(',');
          if (params.length === 4) {
            const [hour, minute, ampm, type] = params;
            console.log(`[Arduino] Keypad schedule: ${hour}:${minute} ${ampm} ${type}`);
            
            // Save to database (associate with admin user ID 1)
            if (this.db) {
              this.db.run(
                `INSERT INTO schedules (user_id, hour, minute, ampm, dispense_type, is_active, created_at) 
                 VALUES (1, ?, ?, ?, ?, 1, CURRENT_TIMESTAMP)`,
                [parseInt(hour), parseInt(minute), ampm.trim(), type.trim()],
                function(err) {
                  if (err) {
                    console.error('Error saving Arduino schedule to database:', err);
                  } else {
                    console.log(`✓ Arduino schedule saved to database (ID: ${this.lastID})`);
                  }
                }
              );
            }
            
            // Broadcast to web clients
            if (this.io) {
              this.io.emit('schedule-created', { 
                source: 'arduino',
                hour: parseInt(hour),
                minute: parseInt(minute),
                ampm: ampm.trim(),
                dispense_type: type.trim()
              });
            }
          }
        }
      }
      
      if (this.io) {
        this.io.emit('arduino-schedule-added', { success: true });
      }
    }
```

---

## File 4: `pet_feeder.ino` (Arduino)

**Location:** Arduino IDE (then upload to Arduino)

**Find this code in the `addSchedule()` function (around line 410):**
```cpp
  // Save schedule
  schedules[slot].hour = hour;
  schedules[slot].minute = minute;
  schedules[slot].isPM = isPM;
  schedules[slot].mode = mode;
  schedules[slot].triggered = false;
  schedules[slot].active = true;
  
  saveScheduleToEEPROM(slot);
  
  // Display confirmation
  lcd.clear();
  char timeStr[16];
  sprintf(timeStr, "%d:%02d %s", hour, minute, isPM ? "PM" : "AM");
  lcd.print(timeStr);
```

**Replace with:**
```cpp
  // Save schedule
  schedules[slot].hour = hour;
  schedules[slot].minute = minute;
  schedules[slot].isPM = isPM;
  schedules[slot].mode = mode;
  schedules[slot].triggered = false;
  schedules[slot].active = true;
  
  saveScheduleToEEPROM(slot);
  
  // Send notification to Raspberry Pi
  Serial.print(F("SCHEDULE_ADDED:"));
  Serial.print(hour);
  Serial.print(F(","));
  Serial.print(minute);
  Serial.print(F(","));
  Serial.print(isPM ? F("PM") : F("AM"));
  Serial.print(F(","));
  if (mode == MODE_FOOD) Serial.println(F("food"));
  else if (mode == MODE_WATER) Serial.println(F("water"));
  else Serial.println(F("both"));
  
  // Display confirmation
  lcd.clear();
  char timeStr[16];
  sprintf(timeStr, "%d:%02d %s", hour, minute, isPM ? "PM" : "AM");
  lcd.print(timeStr);
```

---

## How to Apply These Changes

### Option 1: Edit Directly on Raspberry Pi
```bash
ssh pi@<your-pi-ip>
cd ~/PetFeeder2
nano user/user.js        # Make change 1
nano routes/user.js      # Make change 2
nano serial/arduinoSerial.js  # Make change 3A and 3B
```

### Option 2: Copy from Windows to Pi
```bash
# On Windows, use WinSCP or pscp to copy files:
pscp user/user.js pi@<pi-ip>:/home/pi/PetFeeder2/user/
pscp routes/user.js pi@<pi-ip>:/home/pi/PetFeeder2/routes/
pscp serial/arduinoSerial.js pi@<pi-ip>:/home/pi/PetFeeder2/serial/
```

### Option 3: Use Git
```bash
# On Windows:
git add .
git commit -m "Fix dashboard updates and schedule sync"
git push

# On Raspberry Pi:
cd ~/PetFeeder2
git pull
```

### For Arduino Code:
1. Open Arduino IDE on your computer
2. Make the change to pet_feeder.ino
3. Upload to Arduino via USB

---

## After Making Changes

1. **Restart the server on Raspberry Pi:**
```bash
pm2 restart pet-feeder
# OR
npm start
```

2. **Upload Arduino code** (if you made Arduino changes)

3. **Clear browser cache** and reload the website

4. **Test each issue:**
   - Manual dispense → Check if "Last Feeding" updates
   - Create web schedule → Check Arduino LCD for schedule
   - Add keypad schedule → Check if appears on website
   - Check history page

---

## Files Modified Summary

| File | Location on Pi | What Changed |
|------|---------------|--------------|
| `user/user.js` | `/home/pi/PetFeeder2/user/user.js` | Added `feeding-logged` Socket.IO listener |
| `routes/user.js` | `/home/pi/PetFeeder2/routes/user.js` | Added Arduino sync on schedule creation |
| `serial/arduinoSerial.js` | `/home/pi/PetFeeder2/serial/arduinoSerial.js` | Added `feeding-logged` emit and Arduino notification handler |
| `pet_feeder.ino` | Arduino IDE | Added schedule notification to RPi |

---

## Quick Copy-Paste Commands

If you have SSH access to your Pi from Windows:

```bash
# Copy all 3 JavaScript files at once
scp user/user.js routes/user.js serial/arduinoSerial.js pi@raspberrypi.local:/home/pi/PetFeeder2/
```

Then on Pi:
```bash
cd ~/PetFeeder2
# Move files to correct locations
mv user.js user/
mv user.js routes/
mv arduinoSerial.js serial/

# Restart server
npm start
```
