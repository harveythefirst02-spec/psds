# Arduino Uno Integration Guide
## Complete Setup for RPi ↔ Arduino Communication

---

## 🔌 System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Web Browser (User/Admin)                  │
│              (admin.html, user.html + JS files)              │
└──────────────────┬──────────────────────────────────────────┘
                   │ HTTP / WebSocket (Socket.IO)
                   ↓
┌─────────────────────────────────────────────────────────────┐
│                  Raspberry Pi 4 (Node.js)                    │
│  ┌────────────────────────────────────────────────────────┐ │
│  │  server.js → routes/api.js → serial/arduinoSerial.js  │ │
│  └────────────────────┬───────────────────────────────────┘ │
└───────────────────────┼─────────────────────────────────────┘
                        │ USB Serial (UART)
                        │ Baud: 115200
                        ↓
┌─────────────────────────────────────────────────────────────┐
│               Arduino Uno (pet_feeder.ino)                   │
│  • Receives: DISPENSE_FOOD, DISPENSE_WATER, etc.            │
│  • Responds: FOOD_DONE, WATER_DONE, STATUS_ONLINE, etc.     │
│  • Controls: Servo (Food), Pump (Water), LCD, Keypad, RTC   │
└─────────────────────────────────────────────────────────────┘
```

---

## 📋 Files Directly Involved

### Backend (Raspberry Pi)

| File | Purpose | Key Functions |
|------|---------|---------------|
| `serial/arduinoSerial.js` | Core serial communication bridge | `sendCommand()`, `handleArduinoResponse()`, `connect()` |
| `routes/api.js` | HTTP endpoints for Arduino actions | `/api/dispense/food`, `/api/arduino/status` |
| `server.js` | Initializes serial on startup | `arduinoSerial.initialize(io, db)` |

### Frontend (Web Interface)

| File | Purpose | Key Functions |
|------|---------|---------------|
| `admin/admin.js` | Admin dispense controls | `loadDeviceStatus()`, Socket.IO listeners |
| `user/user.js` | User feed buttons & real-time updates | `dispense()`, `handleDispenseComplete()` |
| `admin/admin.html` | Device monitoring UI | Arduino status display |
| `user/user.html` | Feed control buttons | 3 big buttons: Food, Water, Both |

### Arduino Side

| File | Purpose | Key Functions |
|------|---------|---------------|
| `pet_feeder.ino` | Arduino sketch | `handleSerialCommand()`, `dispenseFoodOnly()`, `dispenseWaterOnly()`, `dispenseBoth()` |

---

## 🔄 Communication Protocol

### Commands (RPi → Arduino)

| Command | Description | Arduino Response |
|---------|-------------|------------------|
| `DISPENSE_FOOD` | Trigger food dispensing | `FOOD_DONE` |
| `DISPENSE_WATER` | Trigger water pump | `WATER_DONE` |
| `DISPENSE_BOTH` | Dispense food and water | `BOTH_DONE` |
| `GET_STATUS` | Request status | `STATUS_ONLINE`, `SCHEDULES:X`, `UPTIME:X` |
| `ADD_SCHEDULE:h,m,ap,type` | Add schedule remotely | `SCHEDULE_ADDED` or `ERROR:...` |

### Responses (Arduino → RPi)

| Response | Meaning | Triggers |
|----------|---------|----------|
| `FOOD_DONE` | Food dispensing completed | Database log, Socket.IO broadcast, UI update |
| `WATER_DONE` | Water dispensing completed | Database log, Socket.IO broadcast, UI update |
| `BOTH_DONE` | Both dispensing completed | Database log, Socket.IO broadcast, UI update |
| `STATUS_ONLINE` | Arduino is alive | Device status update |
| `SCHEDULES:3` | 3 active schedules | Dashboard update |
| `UPTIME:12345` | Uptime in seconds | Admin monitoring |
| `SCHEDULE_ADDED` | Schedule sync successful | Confirmation message |
| `ERROR:UNKNOWN_COMMAND` | Command not recognized | Error notification |
| `ERROR:MEMORY_FULL` | No schedule slots available | Error notification |
| `ERROR:INVALID_TIME` | Invalid hour/minute | Error notification |

---

## 🚀 Setup Steps

### 1. Upload Arduino Code

```bash
# 1. Open Arduino IDE
# 2. File → Open → pet_feeder.ino
# 3. Tools → Board → Arduino Uno
# 4. Tools → Port → Select correct COM/ttyUSB port
# 5. Upload (Ctrl+U)
```

**Required Arduino Libraries:**
- Wire (built-in)
- LiquidCrystal_I2C
- RTClib
- Keypad
- Servo (built-in)
- EEPROM (built-in)

### 2. Connect Arduino to Raspberry Pi

```bash
# Connect Arduino to RPi via USB cable

# Find the port
ls /dev/tty*

# Common ports:
# - /dev/ttyUSB0 (USB to Serial)
# - /dev/ttyACM0 (Arduino Uno)
# - COM3, COM4 (Windows)

# Give permissions (Linux/RPi)
sudo chmod 666 /dev/ttyUSB0
sudo usermod -a -G dialout $USER
```

### 3. Test Communication

```bash
# Run test script
node test_arduino_communication.js

# Expected output:
# ✓ Found potential Arduino on: /dev/ttyUSB0
# ✓ Serial port opened successfully!
# Test 1: Status Check
# → Sending: GET_STATUS
# ← Arduino: STATUS_ONLINE
# ← Arduino: SCHEDULES:0
# ← Arduino: UPTIME:45
```

### 4. Start Server

```bash
# Normal start
npm start

# Development mode (auto-restart)
npm run dev

# Expected console output:
# ✓ Connected to SQLite database
# Available ports: COM3, COM4
# ✓ Connected to Arduino on COM3
# Server running on port 3000
```

---

## 🔍 Debugging Serial Communication

### Check Arduino Serial Monitor

```arduino
// In Arduino IDE, open Serial Monitor
// Set baud rate to 115200
// Send test commands:

GET_STATUS
// Expected: STATUS_ONLINE, SCHEDULES:X, UPTIME:X

DISPENSE_FOOD
// Expected: [Arduino] Executing DISPENSE_FOOD
//           FOOD_DONE
```

### Check Node.js Console

```javascript
// In terminal running server:
// You should see:

[Arduino Response]: STATUS_ONLINE
[Arduino] Status check: Online
Command sent to Arduino: DISPENSE_FOOD
[Arduino Response]: FOOD_DONE
[Arduino] Food dispensing completed
```

### Check Browser Console

```javascript
// In browser DevTools (F12):

// Socket.IO events:
[Arduino Response]: { response: "FOOD_DONE", timestamp: "..." }

// Feed status updates
dispense-complete: { type: "food", status: "success", timestamp: "..." }
```

---

## 🛠️ Troubleshooting

### Arduino Not Found

```bash
# Check if Arduino is connected
ls /dev/tty* | grep -E 'USB|ACM'

# Check permissions
ls -l /dev/ttyUSB0

# Fix permissions
sudo chmod 666 /dev/ttyUSB0

# Restart server
# Press Ctrl+C, then npm start
```

### No Response from Arduino

```bash
# 1. Check baud rate matches (115200)
# 2. Re-upload Arduino sketch
# 3. Check USB cable (use data cable, not charge-only)
# 4. Check Serial Monitor in Arduino IDE
# 5. Restart both Arduino and server
```

### Commands Not Working

```bash
# Verify command format in Arduino code
# Check pet_feeder.ino → handleSerialCommand()

# Test manually with Serial Monitor:
DISPENSE_FOOD
GET_STATUS

# Check server logs for errors
# Look for: "Error sending command" or "Command timeout"
```

### Socket.IO Not Updating

```javascript
// In browser console, check connection:
socket.connected
// Should return: true

// Manually test:
socket.on('arduino-response', (data) => console.log(data));

// Then trigger a feed from UI
```

---

## 📡 Adding Custom Commands

### 1. Add to Arduino Code

```cpp
// In pet_feeder.ino → handleSerialCommand()

else if (command == "MY_COMMAND") {
  Serial.println(F("[Arduino] Executing MY_COMMAND"));
  // Your code here
  Serial.println(F("MY_COMMAND_DONE"));
}
```

### 2. Add to arduinoSerial.js

```javascript
// In handleArduinoResponse()

else if (response.includes('MY_COMMAND_DONE')) {
  console.log('[Arduino] My command completed');
  if (this.io) {
    this.io.emit('my-command-complete', { success: true });
  }
}
```

### 3. Add to routes/api.js

```javascript
router.post('/api/my-action', async (req, res) => {
  try {
    const response = await arduinoSerial.sendCommand('MY_COMMAND');
    res.json({ success: true, response });
  } catch (error) {
    res.json({ success: false, message: 'Failed' });
  }
});
```

### 4. Add to Frontend

```javascript
// In user.js or admin.js

async function myAction() {
  try {
    const response = await fetch('/api/my-action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    });
    const data = await response.json();
    if (data.success) {
      showToast('Action completed!', 'success');
    }
  } catch (error) {
    showToast('Action failed', 'error');
  }
}

// Socket.IO listener
socket.on('my-command-complete', (data) => {
  console.log('My command completed!', data);
});
```

---

## 🔐 Security Considerations

1. **Command Validation**: Arduino validates all incoming commands
2. **Timeout Protection**: Commands timeout after 10 seconds
3. **Error Handling**: All errors are logged and broadcast
4. **Session Required**: All API endpoints require authentication
5. **Admin Commands**: Sensitive commands restricted to admin role

---

## 📊 Monitoring & Logs

### Real-time Monitoring (Admin Dashboard)

1. Navigate to **Device Monitoring** section
2. See live Arduino status (online/offline)
3. View last response and timestamp
4. Monitor serial port information

### Database Logs

```sql
-- All commands sent to Arduino
SELECT * FROM commands ORDER BY created_at DESC LIMIT 50;

-- All feeding operations
SELECT * FROM feeding_logs ORDER BY timestamp DESC LIMIT 50;

-- System logs with Arduino errors
SELECT * FROM system_logs WHERE log_type = 'error' ORDER BY created_at DESC;
```

### System Logs (Terminal)

```bash
# View Node.js console output
# Shows all serial communication in real-time

# Grep for specific events
npm start | grep Arduino
npm start | grep "FOOD_DONE"
```

---

## 🧪 Testing Checklist

- [ ] Arduino uploads successfully
- [ ] Serial port detected by RPi
- [ ] `GET_STATUS` returns `STATUS_ONLINE`
- [ ] `DISPENSE_FOOD` triggers servo and returns `FOOD_DONE`
- [ ] `DISPENSE_WATER` triggers pump and returns `WATER_DONE`
- [ ] `DISPENSE_BOTH` executes both and returns `BOTH_DONE`
- [ ] Web dashboard shows Arduino as "Online"
- [ ] Feed buttons work from user dashboard
- [ ] Real-time updates appear in browser
- [ ] Database logs feeding events correctly
- [ ] Error handling works (disconnect Arduino, click feed)

---

## 📞 Support

For issues with:
- **Arduino code**: Check `pet_feeder.ino` comments
- **Serial communication**: Review `serial/arduinoSerial.js`
- **API endpoints**: Check `routes/api.js`
- **Frontend**: Review `user/user.js` and `admin/admin.js`
- **Database**: Run `node database/init.js` to reset

---

**Last Updated:** June 7, 2026
**Version:** 1.0.0
